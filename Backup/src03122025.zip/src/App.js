import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Footer from './components/Footer';
import './App.css';

function App() {
  const [tabs, setTabs] = useState([]);

  const addTab = (newTab) => {
    if (tabs.length === 0) {
      setTabs([newTab]); // Create the first tab
    } else {
      const updatedTabs = [...tabs];
      updatedTabs[0] = newTab; // Update the first tab
      setTabs(updatedTabs);
    }
  };

  const addSubTab = (subTab) => {
    setTabs([...tabs, subTab]); // Add new tabs
  };

  const removeTab = (mod_name) => {
    setTabs(tabs.filter(tab => tab.mod_name !== mod_name));
  };

  return (
    <div className="app-container">
      <Header />
      <div className="main-content">
        <Sidebar onMenuItemClick={addTab} />
        <Dashboard tabs={tabs} removeTab={removeTab} addSubTab={addSubTab} />
      </div>
      <Footer />
    </div>
  );
}

export default App;
