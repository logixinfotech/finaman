import React, { useState } from 'react';
import './Header.css';
import { FaWhatsapp, FaEnvelope, FaUpload, FaDownload, FaBell, FaHeadset, FaSignOutAlt } from 'react-icons/fa';
import WhatsAppForm from './WhatsAppForm';
// import WhatsAppForm from '../tabs/USERMA';

import logoIcon from './icons/logo.png';

function Header() {
  const [isWhatsAppFormOpen, setIsWhatsAppFormOpen] = useState(false);

  const handleWhatsAppClick = () => {
    setIsWhatsAppFormOpen(true);
  };

  const closeWhatsAppForm = () => {
    setIsWhatsAppFormOpen(false);
  };

  return (
    <div className="header">
      <div className="header-left-logo">
        <img src={logoIcon} alt="Logo" className="logo-icon" />
      </div>
      <div className="header-left">
        <h1>LOGIX INFOTECH LLP</h1>
        <p>Mobile: +91 817-851-0089</p>
        <p>Email: info@logixinfotech.in</p>
      </div>
      <div className="header-center">
        <h1>FINAMAN-ERP</h1>
        <p>(Process Manufacturing Management Software)</p>
        <p><a href="http://www.logixinfotech.in">www.logixinfotech.in</a></p>
      </div>
      <div className="header-right">
        <h1>DEMO FORMULATION PVT. LTD</h1>
        <p>C260-C Block, Sector 63-Noida</p>
        <p>Uttar Pradesh-201310</p>
      </div>
      <div className="button-align">
        <button className="header-btn" onClick={handleWhatsAppClick}>
          <FaWhatsapp className="icon" /> <span>WhatsApp</span>
        </button>
        <button className="header-btn">
          <FaEnvelope className="icon" /> <span>Email</span>
        </button>
        <button className="header-btn">
          <FaUpload className="icon" /> <span>Upload</span>
        </button>
        <button className="header-btn">
          <FaDownload className="icon" /> <span>Download</span>
        </button>
        <button className="header-btn">
          <FaBell className="icon" /> <span>Notification</span>
        </button>
        <button className="header-btn">
          <FaHeadset className="icon" /> <span>Online Support</span>
        </button>
        <button className="header-btn">
          <FaSignOutAlt className="icon" /> <span>Exit</span>
        </button>
      </div>
      {isWhatsAppFormOpen && <WhatsAppForm onClose={closeWhatsAppForm} />}
    </div>
  );
}

export default Header;
