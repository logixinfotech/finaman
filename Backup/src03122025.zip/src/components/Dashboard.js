// src/components/Dashboard.js
import React, { useState, useEffect } from 'react';
import { FaListUl, FaFileAlt } from 'react-icons/fa'; // Import the icons you want to use
import './Dashboard.css';

const DefaultContent = () => <div></div>;
const ErrorContent = () => <div>Error loading content</div>;

const numberToLetter = (num) => {
  let result = '';
  let temp;

  while (num >= 0) {
    temp = num % 26;
    result = String.fromCharCode(temp + 65) + result;
    num = Math.floor(num / 26) - 1;
  }

  return result;
};

function Dashboard({ tabs, removeTab, addSubTab }) {
  const [activeTab, setActiveTab] = useState('');
  const [selectedBarName, setSelectedBarName] = useState('');
  const [activeTabData, setActiveTabData] = useState({ appl_name: '', bar_name: '' });
  const [ContentComponent, setContentComponent] = useState(() => DefaultContent);
  const [selectedCategory, setSelectedCategory] = useState('');

  useEffect(() => {
    if (tabs.length > 0) {
      const firstTab = tabs[0];
      setActiveTab(firstTab.mod_name);
      setActiveTabData({ appl_name: firstTab.appl_name || '', bar_name: '' });
    }
  }, [tabs]);

  useEffect(() => {
    const loadContent = async () => {
      if (activeTabData.appl_name) {
        try {
          const module = await import(`../tabs/${activeTabData.appl_name}`);
          setContentComponent(() => module.default);
        } catch (err) {
          try {
            const commonModule = await import('../tabs/common.js');
            setContentComponent(() => commonModule.default);
          } catch (err) {
            setContentComponent(() => ErrorContent);
          }
        }
      } else {
        setContentComponent(() => DefaultContent);
      }
    };

    loadContent();
  }, [activeTabData]);

  const handleTabClick = (mod_name) => {
    const tab = tabs.find(t => t.mod_name === mod_name);
    if (tab) {
      setActiveTab(mod_name);
      setActiveTabData({ appl_name: tab.appl_name || '', bar_name: '' });
      setSelectedBarName('');
      if (mod_name === tabs[0]?.mod_name) {
        setSelectedCategory('');
      }
    }
  };

  const handleButtonClick = (bar_name, appl_name) => {
    const subTabData = {
      mod_name: `${bar_name}`,
      appl_name: appl_name,
      masmnuData: [{ bar_name, srl_no: 0 }]
    };

    addSubTab(subTabData);

    setTimeout(() => {
      setActiveTab(subTabData.mod_name);
      setActiveTabData({ appl_name: subTabData.appl_name, bar_name: bar_name });
    }, 0);
  };

  const firstTab = tabs[0] || {};
  const barItems = tabs.find(tab => tab.mod_name === activeTab)?.masmnuData?.sort((a, b) => a.srl_no - b.srl_no) || [];
  const pad1Items = barItems.filter(item => item.pad1 === firstTab.pad1);
  const pad2Items = barItems.filter(item => item.pad2 === firstTab.pad2);

  return (
    <div className="dashboard">
      <div className="tabs">
        {tabs.map((tab, index) => (
          <div
            key={index}
            className={`tab ${tab.mod_name === activeTab ? 'active' : ''} ${index === 0 ? 'first-tab' : ''}`}
            onClick={() => handleTabClick(tab.mod_name)}
          >
            <span>{tab.mod_name}</span>
            {index !== 0 && (
              <button
                className="close-button"
                onClick={(e) => { e.stopPropagation(); removeTab(tab.mod_name); }}
              >
                x
              </button>
            )}
          </div>
        ))}
      </div>
      <div className="tab-content">
        {activeTab === firstTab.mod_name ? (
          <div className="tab-panel">
            <div className="category-selection">
              {activeTab === tabs[0].mod_name && (
                <>
                  <label>
                    <input
                      type="radio"
                      name="category"
                      value="Raw Material"
                      checked={selectedCategory === 'Raw Material'}
                      onChange={() => setSelectedCategory('Raw Material')}
                    />
                    <span>Raw Material</span>
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="category"
                      value="Packing Material"
                      checked={selectedCategory === 'Packing Material'}
                      onChange={() => setSelectedCategory('Packing Material')}
                    />
                    <span>Packing Material</span>
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="category"
                      value="Finished Goods"
                      checked={selectedCategory === 'Finished Goods'}
                      onChange={() => setSelectedCategory('Finished Goods')}
                    />
                    <span>Finished Goods</span>
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="category"
                      value="Mis Item"
                      checked={selectedCategory === 'Mis Item'}
                      onChange={() => setSelectedCategory('Mis Item')}
                    />
                    <span>Mis Item</span>
                  </label>
                </>
              )}
            </div>
            <div className="pad-panel pad1-panel">
              <div className="pad-title">
                <FaListUl className="pad-icon" />
                {firstTab.pad1 || 'Entries'}
              </div>
              <div className="bar-name-list">
                {pad1Items.map((item, index) => (
                  item.menu_hide !== "Y" && (
                    <div key={index} className="bar-item">
                      <button
                        className="tab-button"
                        onClick={() => handleButtonClick(item.bar_name, item.appl_name)}
                      >
                        {numberToLetter(index)}
                      </button>
                      <span className="bar-name">{item.bar_name}</span>
                    </div>
                  )
                ))}
              </div>
            </div>
            <div className="pad-panel pad2-panel">
              <div className="pad-title">
                <FaFileAlt className="pad-icon" />
                {firstTab.pad2 || 'Reports'}
              </div>
              <div className="bar-name-list">
                {pad2Items.map((item, index) => (
                  item.menu_hide !== "Y" && (
                    <div key={index} className="bar-item">
                      <button
                        className="tab-button"
                        onClick={() => handleButtonClick(item.bar_name, item.appl_name)}
                      >
                        {numberToLetter(index)}
                      </button>
                      <span className="bar-name">{item.bar_name}</span>
                    </div>
                  )
                ))}
              </div>
            </div>
            {selectedBarName && (
              <div className="bar-name-caption">
                {/* Display additional content based on selectedBarName if needed */}
              </div>
            )}
          </div>
        ) : (
          <ContentComponent appl_name={activeTabData.appl_name} />
        )}
      </div>
    </div>
  );
}

export default Dashboard;
