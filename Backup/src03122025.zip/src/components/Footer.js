import React, { useEffect, useState } from 'react';
import './Footer.css';
import { FaUserCircle } from 'react-icons/fa'; // Import a default user icon from react-icons

function Footer() {
  const [dateTime, setDateTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setDateTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const appVersion = "1.0.0";
  const userName = "Suman";
  const userIcon = null; // Replace with your dynamic user icon path or keep null to use the default icon

  return (
    <footer className="footer">
      <div className="footer-left">
        <div className="footer-item">
          <span className="footer-label">Version:</span>
          <span>{appVersion}</span>
        </div>
        <div className="footer-item">
          <span className="footer-label">Date & Time:</span>
          <span>{dateTime.toLocaleDateString()} {dateTime.toLocaleTimeString()}</span>
        </div>
      </div>
      <div className="footer-center">
        <marquee className="scrolling-text">FINAMAN ERP: Introducing Our Newly Developed Web Application, Enhancing Your Business Efficiency and Streamlining Processes</marquee>
      </div>
      <div className="footer-right">
        <div className="footer-item">
          {userIcon ? (
            <img src={userIcon} alt="User Icon" className="user-icon" />
          ) : (
            <FaUserCircle className="user-icon" />
          )}
          <span>{userName}</span>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
