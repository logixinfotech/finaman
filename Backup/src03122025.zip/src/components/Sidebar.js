import React, { useEffect, useState } from 'react';
import './Sidebar.css';
import { authenticateUser, fetchSidebarMenu, fetchMasmnuData } from '../utils/api';

const importAll = (r) => {
  let icons = {};
  r.keys().forEach((item) => {
    icons[item.replace('./', '')] = r(item);
  });
  return icons;
};

const icons = importAll(require.context('./icons', false, /\.(png|jpe?g|svg)$/));

function Sidebar({ onMenuItemClick }) {
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [token, setToken] = useState(null);
  const [isCollapsed, setIsCollapsed] = useState(window.innerWidth <= 768);

  useEffect(() => {
    const loadMenu = async () => {
      try {
        const authData = await authenticateUser();
        setToken(authData.token);
        const menuData = await fetchSidebarMenu(authData.token);
        setMenuItems(menuData);
      } catch (error) {
        setError(error.message || 'An error occurred while fetching the menu.');
      } finally {
        setLoading(false);
      }
    };

    loadMenu();
  }, []);

  useEffect(() => {
    const handleResize = () => {
      setIsCollapsed(window.innerWidth <= 768);
    };

    window.addEventListener('resize', handleResize);

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleMenuItemClick = async (item) => {
    try {
      if (token) {
        const masmnuData = await fetchMasmnuData(token);
        const filteredTabs = masmnuData.filter(tab => tab.masmod_id === item.masmod_id);

        console.log('Filtered Tabs:', filteredTabs); // Debug

        const tabData = {
          mod_name: item.mod_name,
          masmnuData: filteredTabs.map(tab => ({
            bar_name: tab.bar_name,
            srl_no: tab.srl_no,
            appl_name: tab.appl_name,
            pad1: tab.pad1,
            pad2: tab.pad2
          }))
        };

        console.log('Tab Data:', tabData); // Debug

        onMenuItemClick(tabData);
      }
    } catch (error) {
      console.error('Error fetching masmnu data:', error);
      setError('Failed to fetch submenu data.');
    }
  };

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  if (loading) {
    return <div className="sidebar">Loading...</div>;
  }

  if (error) {
    return <div className="sidebar">Error: {error}</div>;
  }

  return (
    <div className={`sidebar ${isCollapsed ? 'collapsed' : 'expanded'}`}>
      <button className="toggle-button" onClick={toggleSidebar}>
        {isCollapsed ? '+' : '-'}
      </button>
      <ul>
        {menuItems.map((item) => (
          <li key={item.masmod_id} onClick={() => handleMenuItemClick(item)}>
            <img
              src={icons[item.pic_path] || icons['default.png']}
              alt={item.mod_name}
              className="icon"
            />
            <span className="text">{item.mod_name}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Sidebar;
