// src/config.js

// Determine if the app is being accessed from localhost
// const isLocalhost = window.location.hostname === 'localhost';

// Set the API URL based on whether the app is accessed locally or externally
// const apiUrl = isLocalhost ? 'http://localhost:63556' : 'http://122.160.143.110:63556';
// const apiUrl = 'http://122.160.143.110:63556';
// const apiUrl = 'http://122.160.143.110:63556';
const apiUrl = 'http://192.168.1.42:63558';
// const apiUrl = 'http://122.160.143.110:63557';




const config = {
    apiUrl: apiUrl,
    credentials: {
        com_code: 'FINAMAN',
        user_id: 'FINAMAN',
        user_pass: 'FINAMAN',
    },
};

export default config;
