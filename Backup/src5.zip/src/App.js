// src/App.js
import React, { useState } from "react";
import Header from "./components/Header";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import Footer from "./components/Footer";
import "./App.css";

function App() {
  const [theme, setTheme] = useState("light"); // "light" | "dark" | "blue"
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const [activeModule, setActiveModule] = useState(null); // masmod object
  const [tabs, setTabs] = useState([]); // [{id,label,type,module,appl_name}]
  const [activeTabId, setActiveTabId] = useState(null);

  // When user clicks a module in the left sidebar
  const handleModuleClick = (module) => {
    setActiveModule(module);

    const moduleTab = {
      id: `mod-${module.masmod_id}`,
      label: module.mod_name,
      type: "module",
      module,
      appl_name: null,
    };

    setTabs([moduleTab]);
    setActiveTabId(moduleTab.id);
  };

  // When user clicks an Entry/Report card in Dashboard
  const handleOpenPageFromMenu = (menuItem) => {
    const tabId = `page-${menuItem.masmnu_id}`;

    setTabs((prev) => {
      const exists = prev.find((t) => t.id === tabId);
      if (exists) return prev;

      const newTab = {
        id: tabId,
        label: menuItem.bar_name,     // ✅ SHOW REAL NAME
        type: "page",
        module: activeModule,
        appl_name: menuItem.appl_name // ✅ used only for PageRegistry
      };
      return [...prev, newTab];
    });

    setActiveTabId(tabId);
  };


  const handleChangeActiveTab = (tabId) => {
    setActiveTabId(tabId);
  };

  const handleCloseTab = (tabId) => {
    setTabs((prev) => {
      const remaining = prev.filter((t) => t.id !== tabId);

      // If closing active tab, move focus to last tab
      if (tabId === activeTabId) {
        const last = remaining[remaining.length - 1];
        setActiveTabId(last ? last.id : null);
      }

      return remaining;
    });
  };

  const toggleTheme = () => {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  };

  const setBlueTheme = () => setTheme("blue");

  const toggleSidebar = () => setSidebarCollapsed((prev) => !prev);

  const activeTab = tabs.find((t) => t.id === activeTabId) || null;

  return (
    <div
      className={`app-shell theme-${theme}`}
    >
      <Header
        theme={theme}
        onToggleTheme={toggleTheme}
        onBlueTheme={setBlueTheme}
        onToggleSidebar={toggleSidebar}
        activeModule={activeModule}
      />

      <div className="app-body">
        <div className={`app-sidebar ${sidebarCollapsed ? "collapsed" : ""}`}>
          <Sidebar
            collapsed={sidebarCollapsed}
            onMenuItemClick={handleModuleClick}
          />
        </div>

        <div className="app-content">
          <Dashboard
            theme={theme}
            activeModule={activeModule}
            tabs={tabs}
            activeTab={activeTab}
            onOpenPage={handleOpenPageFromMenu}
            onChangeActiveTab={handleChangeActiveTab}
            onCloseTab={handleCloseTab}
          />
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default App;
