import React from "react";
import "./Footer.css";

function Footer() {
  return (
    <footer className="erp-footer">
      <span>© {new Date().getFullYear()} LOGIX INFOTECH LLP • FINAMAN ERP</span>
      <span className="erp-footer-right">
        Version 1.0.0 • {new Date().toLocaleString()}
      </span>
    </footer>
  );
}

export default Footer;
