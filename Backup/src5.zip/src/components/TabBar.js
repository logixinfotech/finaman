import React from "react";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import "./TabBar.css";

function TabBar({
    tabs,
    activeTab,
    onChangeActiveTab,
    onCloseTab,
    onReorderTabs, // ✅ new prop
}) {
    const handleDragEnd = (result) => {
        if (!result.destination) return;

        const items = Array.from(tabs);
        const [moved] = items.splice(result.source.index, 1);
        items.splice(result.destination.index, 0, moved);

        onReorderTabs(items);
    };

    return (
        <div className="chrome-tabbar">
            <DragDropContext onDragEnd={handleDragEnd}>
                <Droppable droppableId="tabs" direction="horizontal">
                    {(provided) => (
                        <div
                            className="chrome-tab-list"
                            ref={provided.innerRef}
                            {...provided.droppableProps}
                        >
                            {tabs.map((tab, index) => (
                                <Draggable
                                    key={tab.id}
                                    draggableId={tab.id}
                                    index={index}
                                >
                                    {(provided) => (
                                        <div
                                            ref={provided.innerRef}
                                            {...provided.draggableProps}
                                            {...provided.dragHandleProps}
                                            className={`chrome-tab ${activeTab?.id === tab.id ? "active" : ""
                                                }`}
                                            onClick={() => onChangeActiveTab(tab.id)}
                                        >
                                            <span className="chrome-tab-title">
                                                {tab.label}
                                            </span>

                                            {/* ✅ Only pages are closable, first module tab not */}
                                            {tab.type !== "module" && (
                                                <span
                                                    className="chrome-tab-close"
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        onCloseTab(tab.id);
                                                    }}
                                                >
                                                    ×
                                                </span>
                                            )}
                                        </div>
                                    )}
                                </Draggable>
                            ))}

                            {provided.placeholder}
                        </div>
                    )}
                </Droppable>
            </DragDropContext>
        </div>
    );
}

export default TabBar;
