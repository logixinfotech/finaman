import React, { useEffect, useState } from "react";
import "./Sidebar.css";
import {
  authenticateUser,
  fetchSidebarMenu, // must return masmod list
} from "../utils/api";
import DynamicIcon from "./DynamicIcon";

function Sidebar({ onMenuItemClick, collapsed = false }) {
  const [modules, setModules] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [activeId, setActiveId] = useState(null);

  useEffect(() => {
    const loadModules = async () => {
      setLoading(true);
      setError(null);
      try {
        const auth = await authenticateUser();
        const token =
          auth?.token ||
          auth?.Token ||
          auth?.access_token;

        if (!token) throw new Error("Token not received from authenticateUser");
        sessionStorage.setItem("token", token);

        const data = await fetchSidebarMenu(token); // /api/masmod

        const visible = (data || [])
          .filter((m) => m.show_stat === "Y")
          .sort((a, b) => (a.mod_srl || 0) - (b.mod_srl || 0));

        setModules(visible);
      } catch (err) {
        console.error("Sidebar error:", err);
        setError(err.message || "Failed to load modules");
      } finally {
        setLoading(false);
      }
    };

    loadModules();
  }, []);

  const handleClick = (module) => {
    setActiveId(module.masmod_id);
    onMenuItemClick && onMenuItemClick(module);
  };

  return (
    <aside className={`sidebar-shell ${collapsed ? "collapsed" : ""}`}>
      <div className="sidebar-scroll">
        {loading && <div className="sidebar-status">Loading modules...</div>}
        {error && <div className="sidebar-error">{error}</div>}

        <ul className="sidebar-menu">
          {modules.map((m) => (
            <li
              key={m.masmod_id}
              className={`sidebar-item ${activeId === m.masmod_id ? "active" : ""
                }`}
              onClick={() => handleClick(m)}
              title={m.mod_name}
            >
              <div className="sidebar-icon-wrap">
                <DynamicIcon name={m.icon_name} />
              </div>
              {!collapsed && (
                <span className="sidebar-label">{m.mod_name}</span>
              )}
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
}

export default Sidebar;
