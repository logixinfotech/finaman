import React from "react";
import { MdMenu, MdLightMode, MdDarkMode, MdColorLens } from "react-icons/md";
import "./Header.css";

function Header({
  theme,
  onToggleTheme,
  onBlueTheme,
  onToggleSidebar,
  activeModule,
}) {
  return (
    <header className="erp-header">
      <div className="erp-header-left">
        <button className="icon-button" onClick={onToggleSidebar}>
          <MdMenu />
        </button>
        <div className="erp-logo-block">
          <div className="erp-logo-circle">F</div>
          <div className="erp-logo-text">
            <div className="erp-product-name">FINAMAN ERP</div>
            <div className="erp-product-sub">Process Manufacturing Suite</div>
          </div>
        </div>
      </div>

      <div className="erp-header-center">
        {activeModule ? (
          <>
          </>
        ) : (
          <span className="erp-module-placeholder">
            Select a module from the left
          </span>
        )}
      </div>

      <div className="erp-header-right">
        <button
          className="icon-button"
          onClick={onToggleTheme}
          title="Toggle Light / Dark"
        >
          {theme === "dark" ? <MdLightMode /> : <MdDarkMode />}
        </button>

        <button
          className="icon-button"
          onClick={onBlueTheme}
          title="Blue theme"
        >
          <MdColorLens />
        </button>

        <div className="erp-user-chip">
          <div className="avatar">S</div>
          <div className="user-info">
            <div className="user-name">Suman</div>
            <div className="user-role">Administrator</div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;
