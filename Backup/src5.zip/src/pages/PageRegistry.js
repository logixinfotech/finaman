import Master from "./Master";
import TestingRequisition from "./TestingRequisition";
import EmployeeMaster from "./EmployeeMaster";

// Map appl_name from masmnu → React component
const PageRegistry = {
    Master,
    TestingRequisition,
    EmployeeMaster,
    // Add more like:
    // "CustomerMaster": CustomerMaster,
    // "StoreMaterialReceiving": StoreMaterialReceiving,
};

export default PageRegistry;
