// src/config.js

// Decide API URL
const getApiUrl = () => {
  // Highest priority: environment variable (for build/server)
  if (process.env.REACT_APP_API_URL) {
    return process.env.REACT_APP_API_URL;
  }

  const hostname = window.location.hostname;

  // Local dev
  if (hostname === "localhost" || hostname === "127.0.0.1") {
    return "http://localhost:63558"; // your local API port
  }

  // LAN / office network (example)
  if (hostname.startsWith("192.168.1.")) {
    return "http://192.168.1.42:63558";
  }

  // Public / static IP (you can change this)
  return "http://122.160.143.110:63558";
};

const config = {
  apiUrl: getApiUrl(),
  credentials: {
    com_code: "FINAMAN",
    user_id: "FINAMAN",
    user_pass: "FINAMAN",
  },
};

export default config;
