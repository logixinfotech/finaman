const axios = require('axios');
const config = require('../config');

const api = axios.create({
    baseURL: config.apiUrl,
    headers: {
        'Content-Type': 'application/json',
    },
});

const authenticateUser = async () => {
    try {
        const response = await api.post('/api/authenticate', {
            com_code: config.credentials.com_code,
            user_id: config.credentials.user_id,
            user_pass: config.credentials.user_pass,
        });
        console.log('API response:', response.data);
        return response.data;
    } catch (error) {
        console.error('Error during authentication:', error);
        throw error;
    }
};

const fetchSidebarMenu = async (token) => {
    try {
        const response = await api.get('/api/masmod', {
            headers: {
                Authorization: token,
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching sidebar menu:', error);
        throw error;
    }
};

module.exports = {
    authenticateUser,
    fetchSidebarMenu,
};
