// src/components/Sidebar.js
import React, { useEffect, useState } from 'react';
import './Sidebar.css';
import { authenticateUser, fetchSidebarMenu } from '../utils/api'; // Ensure this matches your exports


// Dynamically import icons
const importAll = (r) => {
    let icons = {};
    r.keys().forEach((item) => {
        icons[item.replace('./', '')] = r(item);
    });
    return icons;
};

const icons = importAll(require.context('./icons', false, /\.(png|jpe?g|svg)$/));

function Sidebar() {
    const [menuItems, setMenuItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    useEffect(() => {
        console.log('useEffect triggered');
  
        const loadMenu = async () => {
            try {
                const authData = await authenticateUser();
                const token = authData.token;
                const menuData = await fetchSidebarMenu(token);
                setMenuItems(menuData);
            } catch (error) {
                console.error('Error loading menu:', error);
                setError(error.message || 'An error occurred');
            } finally {
                setLoading(false);
            }
        };

        loadMenu();
    }, []);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    return (
        <div className="sidebar">
            <ul>
                {menuItems.map((item) => (
                    <li key={item.masmod_id}>
                        <img
                            src={icons[item.pic_path]?.default}
                            alt={item.mod_name}
                            className="icon"
                        />
                        {item.mod_name}
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default Sidebar;
