import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Footer from './components/Footer';
import './App.css';

function App() {
  const [tabs, setTabs] = useState([]);

  const addTab = (newTab) => {
    // Check if tab already exists based on mod_name
    const existingTab = tabs.find(tab => tab.mod_name === newTab.mod_name);
    if (existingTab) {
      // Update the existing tab's masmnuData
      setTabs(tabs.map(tab => 
        tab.mod_name === newTab.mod_name ? { ...tab, masmnuData: newTab.masmnuData } : tab
      ));
    } else {
      // Add new tab
      setTabs([...tabs, newTab]);
    }
  };

  const removeTab = (mod_name) => {
    setTabs(tabs.filter(tab => tab.mod_name !== mod_name));
  };

  return (
    <div className="app-container">
      <Header />
      <div className="main-content">
        <Sidebar onMenuItemClick={addTab} />
        <Dashboard tabs={tabs} removeTab={removeTab} />
      </div>
      <Footer />
    </div>
  );
}

export default App;
