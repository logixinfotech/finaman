import React, { useEffect, useState } from "react";
import "./Dashboard.css";
import { fetchMasmnuData } from "../utils/api";
import TabBar from "./TabBar";
import PageRegistry from "../pages/PageRegistry";

function Dashboard({
  activeModule,
  tabs,
  activeTab,
  onOpenPage,
  onChangeActiveTab,
  onCloseTab,
  setTabs,
}) {
  const [menus, setMenus] = useState([]);
  const [loading, setLoading] = useState(false);

  // =============================
  // LOAD MENUS FOR ACTIVE MODULE
  // =============================
  useEffect(() => {
    const loadMenus = async () => {
      if (!activeModule) {
        setMenus([]);
        return;
      }

      setLoading(true);
      try {
        const token = sessionStorage.getItem("token");
        const data = await fetchMasmnuData(token);

        const filtered = (data || []).filter(
          (x) =>
            x.masmod_id === activeModule.masmod_id &&
            x.menu_hide !== "Y"
        );

        setMenus(filtered);
      } catch (err) {
        console.error("Dashboard masmnu error:", err);
        setMenus([]);
      } finally {
        setLoading(false);
      }
    };

    loadMenus();
  }, [activeModule]);

  // =============================
  // ENTRY / REPORT SPLIT
  // =============================
  const entries = menus.filter((m) => m.pad_type === "1");
  const reports = menus.filter((m) => m.pad_type === "2");

  // =============================
  // MODULE DASHBOARD VIEW
  // =============================
  const renderModuleDashboard = () => (
    <div className="module-board modern-card">

      {/* ================= ENTRIES ================= */}
      <section className="dashboard-section entries">
        <div className="section-title">Entries</div>

        {loading && <div className="section-status">Loading…</div>}
        {!loading && !entries.length && (
          <div className="section-status muted">
            No entries configured.
          </div>
        )}

        <div className="dashboard-card-grid">
          {entries.map((m) => (
            <div
              key={m.masmnu_id}
              className="dashboard-card entry-card"
              onClick={() => onOpenPage(m)}
            >
              <div className="dashboard-card-title">
                {m.bar_name}
              </div>
              <div className="dashboard-card-sub">
                Click to open
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ================= REPORTS ================= */}
      <section className="dashboard-section reports">
        <div className="section-title">Reports</div>

        {loading && <div className="section-status">Loading…</div>}
        {!loading && !reports.length && (
          <div className="section-status muted">
            No reports configured.
          </div>
        )}

        <div className="dashboard-card-grid">
          {reports.map((m) => (
            <div
              key={m.masmnu_id}
              className="dashboard-card report-card"
              onClick={() => onOpenPage(m)}
            >
              <div className="dashboard-card-title">
                {m.bar_name}
              </div>
              <div className="dashboard-card-sub">
                Click to open
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );

  // =============================
  // ACTIVE TAB PAGE RENDER
  // =============================
  const renderActivePage = () => {
    if (!activeTab) return null;

    if (activeTab.type === "module") {
      return renderModuleDashboard();
    }

    const Component =
      activeTab.appl_name && PageRegistry[activeTab.appl_name]
        ? PageRegistry[activeTab.appl_name]
        : null;

    // ✅ SAFE FALLBACK – NEVER SHOW "CONTENT NOT AVAILABLE"
    if (!Component) {
      return (
        <div className="page-wrapper modern-card">
          <h2>{activeTab.label}</h2>
          <p>This screen will be dynamically rendered.</p>
        </div>
      );
    }

    return <Component tab={activeTab} module={activeTab.module} />;
  };

  // =============================
  // FINAL RENDER
  // =============================
  return (
    <div className="dashboard-shell">

      {/* ======== CHROME STYLE TABS ======== */}
      <TabBar
        tabs={tabs}
        activeTab={activeTab}
        onChangeActiveTab={onChangeActiveTab}
        onCloseTab={onCloseTab}
        onReorderTabs={setTabs}
      />

      {/* ======== RIGHT WORKSPACE ======== */}
      <div className="dashboard-content">
        {!activeModule ? (
          <div className="no-module modern-card">
            <h2>Welcome to FINAMAN ERP</h2>
            <p>Select a module from the left panel to begin.</p>
          </div>
        ) : (
          renderActivePage()
        )}
      </div>
    </div>
  );
}

export default Dashboard;
