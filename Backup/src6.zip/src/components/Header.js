import React from "react";
import "./Header.css";
import { FaBell, FaMoon, FaSun, FaPalette, FaBars } from "react-icons/fa";

function Header({
  theme,
  setTheme,
  onToggleSidebar,
  activeModule,
}) {
  // ✅ Dummy notification count (later from API)
  const notificationCount = 3;

  return (
    <header className="erp-header">

      {/* LEFT */}
      <div className="erp-header-left">
        <button
          className="icon-button"
          onClick={onToggleSidebar}
          title="Toggle Sidebar"
        >
          <FaBars />
        </button>

        <div className="erp-logo-block">
          <div className="erp-logo-circle">F</div>
          <div className="erp-logo-text">
            <div className="erp-product-name">FINAMAN ERP</div>
            <div className="erp-product-sub">Quality Management</div>
          </div>
        </div>
      </div>

      {/* CENTER – ACTIVE MODULE */}
      <div className="erp-header-center">
        {activeModule ? (
          <>
            <span className="erp-module-label">Module:</span>
            <span className="erp-module-name">
              {activeModule.mod_name}
            </span>
          </>
        ) : (
          <span className="erp-module-placeholder">
            Select a module
          </span>
        )}
      </div>

      {/* RIGHT */}
      <div className="erp-header-right">

        {/* ✅ THEME CONTROLS */}
        <button
          className={`icon-button ${theme === "theme-light" ? "active" : ""}`}
          title="Light Theme"
          onClick={() => setTheme("theme-light")}
        >
          <FaSun />
        </button>

        <button
          className={`icon-button ${theme === "theme-dark" ? "active" : ""}`}
          title="Dark Theme"
          onClick={() => setTheme("theme-dark")}
        >
          <FaMoon />
        </button>

        <button
          className={`icon-button ${theme === "theme-blue" ? "active" : ""}`}
          title="Accent Theme"
          onClick={() => setTheme("theme-blue")}
        >
          <FaPalette />
        </button>

        {/* ✅ NOTIFICATION ICON */}
        <div className="notification-wrap" title="Notifications">
          <FaBell className="notification-icon" />
          {notificationCount > 0 && (
            <span className="notification-badge">
              {notificationCount}
            </span>
          )}
        </div>

        {/* USER CHIP (Already in your project, unchanged logic) */}
        <div className="erp-user-chip">
          <div className="avatar">S</div>
          <div>
            <div className="user-name">Suman</div>
          </div>
        </div>

      </div>
    </header>
  );
}

export default Header;
