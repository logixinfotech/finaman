// src/App.js
import React, { useEffect, useState } from "react";
import Header from "./components/Header";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import Footer from "./components/Footer";
import "./App.css";

function App() {

  // ✅ THEME STATE (CONTROLLED ONLY BY HEADER)
  const [theme, setTheme] = useState("theme-light"); // theme-light | theme-dark | theme-blue
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const [activeModule, setActiveModule] = useState(null); // masmod object
  const [tabs, setTabs] = useState([]); // [{id,label,type,module,appl_name}]
  const [activeTabId, setActiveTabId] = useState(null);

  // =========================
  // LOAD THEME FROM STORAGE
  // =========================
  useEffect(() => {
    const savedTheme = localStorage.getItem("finaman-theme");
    if (savedTheme) {
      setTheme(savedTheme);
    }
  }, []);

  // =========================
  // APPLY THEME TO ROOT
  // =========================
  useEffect(() => {
    document.body.className = theme;
    localStorage.setItem("finaman-theme", theme);
  }, [theme]);

  // =========================
  // WHEN USER CLICKS MODULE
  // =========================
  const handleModuleClick = (module) => {
    setActiveModule(module);

    const moduleTab = {
      id: `mod-${module.masmod_id}`,
      label: module.mod_name,
      type: "module",
      module,
      appl_name: null,
    };

    setTabs([moduleTab]);
    setActiveTabId(moduleTab.id);
  };

  // =========================
  // WHEN USER CLICKS ENTRY/REPORT
  // =========================
  const handleOpenPageFromMenu = (menuItem) => {
    const tabId = `page-${menuItem.masmnu_id}`;

    setTabs((prev) => {
      const exists = prev.find((t) => t.id === tabId);
      if (exists) return prev;

      const newTab = {
        id: tabId,
        label: menuItem.bar_name,
        type: "page",
        module: activeModule,
        appl_name: menuItem.appl_name,
      };

      return [...prev, newTab];
    });

    setActiveTabId(tabId);
  };

  // =========================
  // SWITCH ACTIVE TAB
  // =========================
  const handleChangeActiveTab = (tabId) => {
    setActiveTabId(tabId);
  };

  // =========================
  // CLOSE TAB
  // =========================
  const handleCloseTab = (tabId) => {
    setTabs((prev) => {
      const remaining = prev.filter((t) => t.id !== tabId);

      if (tabId === activeTabId) {
        const last = remaining[remaining.length - 1];
        setActiveTabId(last ? last.id : null);
      }

      return remaining;
    });
  };

  // =========================
  // SIDEBAR TOGGLE
  // =========================
  const toggleSidebar = () => {
    setSidebarCollapsed((prev) => !prev);
  };

  // =========================
  // ACTIVE TAB OBJECT
  // =========================
  const activeTab = tabs.find((t) => t.id === activeTabId) || null;

  // =========================
  // FINAL RENDER
  // =========================
  return (
    <div className={`app-shell ${theme}`}>

      <Header
        theme={theme}
        setTheme={setTheme}
        onToggleSidebar={toggleSidebar}
        activeModule={activeModule}
      />

      <div className="app-body">

        <div className={`app-sidebar ${sidebarCollapsed ? "collapsed" : ""}`}>
          <Sidebar
            collapsed={sidebarCollapsed}
            onMenuItemClick={handleModuleClick}
          />
        </div>

        <div className="app-content">
          <Dashboard
            theme={theme}
            activeModule={activeModule}
            tabs={tabs}
            activeTab={activeTab}
            onOpenPage={handleOpenPageFromMenu}
            onChangeActiveTab={handleChangeActiveTab}
            onCloseTab={handleCloseTab}
            setTabs={setTabs}
          />
        </div>

      </div>

      <Footer activeModule={activeModule} />

    </div>
  );
}

export default App;
