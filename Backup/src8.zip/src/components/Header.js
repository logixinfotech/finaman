import React from "react";
import "./Header.css";
import { FaBell, FaMoon, FaSun, FaPalette, FaBars } from "react-icons/fa";

function Header({
  theme,
  setTheme,
  onToggleSidebar,
  activeModule,
}) {
  const notificationCount = 3; // later from API

  // ✅ Light ↔ Dark toggle only
  const toggleLightDark = () => {
    setTheme(theme === "theme-dark" ? "theme-light" : "theme-dark");
  };

  // ✅ Cycle through 5 professional themes
  const toggleAccentColor = () => {
    setTheme((prev) => {
      const themes = [
        "theme-green",
        "theme-blue",
        "theme-purple",
        "theme-teal",
        "theme-orange"
      ];

      const currentIndex = themes.indexOf(prev);
      const nextIndex = (currentIndex + 1) % themes.length;

      return themes[nextIndex];
    });
  };


  return (
    <header className="erp-header">

      {/* ================= LEFT ================= */}
      <div className="erp-header-left">
        <button
          className="icon-button"
          onClick={onToggleSidebar}
          title="Toggle Sidebar"
        >
          <FaBars />
        </button>

        <div className="erp-logo-block">
          <div className="erp-logo-circle">F</div>
          <div className="erp-logo-text">
            <div className="erp-product-name">FINAMAN ERP</div>
            <div className="erp-product-sub">Quality Management</div>
          </div>
        </div>
      </div>

      {/* ================= CENTER ================= */}
      <div className="erp-header-center">
        {activeModule ? (
          <>
            <span className="erp-module-label">Module:</span>
            <span className="erp-module-name">
              {activeModule.mod_name}
            </span>
          </>
        ) : (
          <span className="erp-module-placeholder">
            Select a module
          </span>
        )}
      </div>

      {/* ================= RIGHT ================= */}
      <div className="erp-header-right">

        {/* ✅ LIGHT / DARK TOGGLE */}
        <button
          className="icon-button"
          title="Toggle Light / Dark"
          onClick={toggleLightDark}
        >
          {theme === "theme-dark" ? <FaSun /> : <FaMoon />}
        </button>

        {/* ✅ ACCENT COLOR TOGGLE (GREEN ↔ BLUE) */}
        <button
          className="icon-button"
          title="Toggle Accent Color"
          onClick={toggleAccentColor}
        >
          <FaPalette />
        </button>

        {/* ✅ NOTIFICATION */}
        <div className="notification-wrap" title="Notifications">
          <FaBell className="notification-icon" />
          {notificationCount > 0 && (
            <span className="notification-badge">
              {notificationCount}
            </span>
          )}
        </div>

        {/* USER CHIP */}
        <div className="erp-user-chip">
          <div className="avatar">S</div>
          <div className="user-name">Suman</div>
        </div>

      </div>
    </header>
  );
}

export default Header;
