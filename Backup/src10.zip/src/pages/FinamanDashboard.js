import React, { useEffect, useState } from "react";
import "./FinamanDashboard.css";

// ✅ CHART.JS REGISTRATION (THIS FIXES YOUR ERROR)
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    LineElement,
    PointElement,
    ArcElement,
    Tooltip,
    Legend,
} from "chart.js";

import { Line, Bar, Pie } from "react-chartjs-2";

// ✅ REGISTER ALL REQUIRED CHART PARTS
ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    LineElement,
    PointElement,
    ArcElement,
    Tooltip,
    Legend
);

function FinamanDashboard() {
    const [loading, setLoading] = useState(true);
    const [data, setData] = useState({});

    // ✅ SAMPLE STATIC DATA (NO API)
    useEffect(() => {
        setTimeout(() => {
            setData({
                months: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
                sales: [120, 190, 300, 280, 250, 400],

                products: ["Tablet", "Capsule", "Injection", "Syrup"],
                productSales: [180, 260, 140, 220],

                categories: ["Production", "QC", "Warehouse"],
                distribution: [45, 30, 25],
            });
            setLoading(false);
        }, 800);
    }, []);

    if (loading) return <div className="finaman-loading">Loading Dashboard...</div>;

    // ✅ CHART CONFIGS
    const lineData = {
        labels: data.months,
        datasets: [
            {
                label: "Monthly Sales",
                data: data.sales,
                borderColor: "#4CAF50",
                backgroundColor: "rgba(76,175,80,0.2)",
                tension: 0.4,
            },
        ],
    };

    const barData = {
        labels: data.products,
        datasets: [
            {
                label: "Product Performance",
                data: data.productSales,
                backgroundColor: ["#22c55e", "#3b82f6", "#f97316", "#9333ea"],
            },
        ],
    };

    const pieData = {
        labels: data.categories,
        datasets: [
            {
                data: data.distribution,
                backgroundColor: ["#10b981", "#0ea5e9", "#f59e0b"],
            },
        ],
    };

    return (
        <div className="finaman-dashboard">

            <div className="finaman-cards">
                <div className="finaman-card">
                    <h3>Sales Overview</h3>
                    <Line data={lineData} />
                </div>

                <div className="finaman-card">
                    <h3>Product Performance</h3>
                    <Bar data={barData} />
                </div>

                <div className="finaman-card">
                    <h3>Department Distribution</h3>
                    <Pie data={pieData} />
                </div>
            </div>

        </div>
    );
}

export default FinamanDashboard;
