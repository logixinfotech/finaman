const mockTasks = [
    {
        id: 1,
        title: "Create ERP Dashboard",
        description: "Build modern dashboard UI",
        priority: "High",
        status: "todo",
        dueDate: "2026-06-15",
        project: "Design",
        assignee: "Suman",
        tags: ["ERP", "Dashboard"]
    },

    {
        id: 2,
        title: "Task Management Module",
        description: "Build task management frontend",
        priority: "Medium",
        status: "inprogress",
        dueDate: "2026-06-20",
        project: "Development",
        assignee: "Developer",
        tags: ["React"]
    },

    {
        id: 3,
        title: "Testing",
        description: "Testing module",
        priority: "Low",
        status: "done",
        dueDate: "2026-06-10",
        project: "QA",
        assignee: "Tester",
        tags: ["QA"]
    }
];

export default mockTasks;