export default function TaskStats({ tasks = [] }) {

    const total = tasks.length;

    const inProgress =
        tasks.filter(
            (x) => x.status === "inprogress"
        ).length;

    const completed =
        tasks.filter(
            (x) => x.status === "done"
        ).length;

    const overdue =
        tasks.filter(
            (x) => x.overdue === true
        ).length;

    return (
        <div className="stats-grid">

            <div className="stat-card total">
                <h3>{total}</h3>
                <span>Total Tasks</span>
            </div>

            <div className="stat-card progress">
                <h3>{inProgress}</h3>
                <span>In Progress</span>
            </div>

            <div className="stat-card completed">
                <h3>{completed}</h3>
                <span>Completed</span>
            </div>

            <div className="stat-card overdue">
                <h3>{overdue}</h3>
                <span>Overdue</span>
            </div>

        </div>
    );
}