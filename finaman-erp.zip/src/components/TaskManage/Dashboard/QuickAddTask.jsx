import { Plus } from "lucide-react";

export default function QuickAddTask() {
    return (
        <div className="quick-add-card">

            <div className="quick-header">
                <Plus size={18} />
                <span>Quick Add Task</span>
            </div>

            <div className="quick-body">

                <input
                    type="text"
                    placeholder="Enter task title..."
                />

                <select>
                    <option>High</option>
                    <option>Medium</option>
                    <option>Low</option>
                </select>

                <button>
                    Add Task
                </button>

            </div>

        </div>
    );
}