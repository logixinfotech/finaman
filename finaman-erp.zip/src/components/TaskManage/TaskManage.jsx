import { useState } from "react";

import TaskSidebar from "./Layout/TaskSidebar";
import TaskTopbar from "./Layout/TaskTopbar";

import TaskStats from "./Dashboard/TaskStats";
import QuickAddTask from "./Dashboard/QuickAddTask";

import TaskGrid from "./Tasks/TaskGrid";
import TaskList from "./Tasks/TaskList";
import TaskKanban from "./Tasks/TaskKanban";
import TaskFilters from "./Tasks/TaskFilters";

import TaskModal from "./Modal/TaskModal";

import useTaskStore from "./hooks/useTaskStore";

import "./styles/task.css";

export default function TaskManage() {

    const [sidebarCollapsed, setSidebarCollapsed] =
        useState(false);

    const [view, setView] =
        useState("grid");

    const [filter, setFilter] =
        useState("all");

    const [modalOpen, setModalOpen] =
        useState(false);

    const {
        tasks,
        addTask
    } = useTaskStore();

    const filteredTasks =
        Array.isArray(tasks)
            ? tasks.filter((task) => {

                if (filter === "all")
                    return true;

                if (filter === "high")
                    return task.priority === "High";

                if (
                    filter === "todo" ||
                    filter === "inprogress" ||
                    filter === "done"
                ) {
                    return task.status === filter;
                }

                return true;
            })
            : [];

    return (
        <div className="tm-layout">

            <TaskSidebar
                collapsed={sidebarCollapsed}
                setCollapsed={setSidebarCollapsed}
            />

            <div className="tm-main">

                <TaskTopbar
                    onAddTask={() =>
                        setModalOpen(true)
                    }
                />

                <div className="tm-content">

                    <TaskStats
                        tasks={filteredTasks}
                    />

                    <QuickAddTask />

                    <div className="toolbar">

                        <TaskFilters
                            filter={filter}
                            setFilter={setFilter}
                        />

                        <div className="view-switch">

                            <button
                                className={
                                    view === "grid"
                                        ? "active"
                                        : ""
                                }
                                onClick={() =>
                                    setView("grid")
                                }
                            >
                                Grid
                            </button>

                            <button
                                className={
                                    view === "list"
                                        ? "active"
                                        : ""
                                }
                                onClick={() =>
                                    setView("list")
                                }
                            >
                                List
                            </button>

                            <button
                                className={
                                    view === "kanban"
                                        ? "active"
                                        : ""
                                }
                                onClick={() =>
                                    setView("kanban")
                                }
                            >
                                Kanban
                            </button>

                        </div>

                    </div>

                    {view === "grid" && (
                        <TaskGrid
                            tasks={filteredTasks}
                        />
                    )}

                    {view === "list" && (
                        <TaskList
                            tasks={filteredTasks}
                        />
                    )}

                    {view === "kanban" && (
                        <TaskKanban
                            tasks={filteredTasks}
                        />
                    )}

                </div>

            </div>

            <TaskModal
                open={modalOpen}
                onClose={() =>
                    setModalOpen(false)
                }
                onSave={addTask}
            />

        </div>
    );
}