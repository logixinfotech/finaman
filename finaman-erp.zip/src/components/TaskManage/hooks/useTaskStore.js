import { useState } from "react";
import mockTasks from "../data/mockTasks";

export default function useTaskStore() {

    const [tasks, setTasks] =
        useState(mockTasks);

    const addTask = (task) => {
        setTasks((prev) => [
            task,
            ...prev
        ]);
    };

    return {
        tasks,
        setTasks,
        addTask
    };
}