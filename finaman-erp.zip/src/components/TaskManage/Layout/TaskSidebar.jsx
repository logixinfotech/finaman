import {
    Home,
    ClipboardList,
    Calendar,
    AlertTriangle,
    KanbanSquare,
    Settings,
    Menu,
} from "lucide-react";

export default function TaskSidebar({
    collapsed,
    setCollapsed,
}) {
    return (
        <aside
            className={`tm-sidebar ${collapsed ? "collapsed" : ""
                }`}
        >
            <div className="tm-logo">
                <button
                    className="menu-btn"
                    onClick={() =>
                        setCollapsed(!collapsed)
                    }
                >
                    <Menu size={18} />
                </button>

                {!collapsed && (
                    <div>
                        <h2>FINAMAN</h2>
                        <span>TASKS</span>
                    </div>
                )}
            </div>

            <div className="tm-menu">
                <div className="menu-item active">
                    <Home size={18} />
                    {!collapsed && <span>Dashboard</span>}
                </div>

                <div className="menu-item">
                    <ClipboardList size={18} />
                    {!collapsed && <span>My Tasks</span>}
                </div>

                <div className="menu-item">
                    <Calendar size={18} />
                    {!collapsed && <span>Due Today</span>}
                </div>

                <div className="menu-item">
                    <AlertTriangle size={18} />
                    {!collapsed && <span>Overdue</span>}
                </div>

                <div className="menu-item">
                    <KanbanSquare size={18} />
                    {!collapsed && <span>Kanban</span>}
                </div>
            </div>

            <div className="tm-footer">
                {!collapsed && (
                    <>
                        <Settings size={18} />
                        <span>Settings</span>
                    </>
                )}
            </div>
        </aside>
    );
}