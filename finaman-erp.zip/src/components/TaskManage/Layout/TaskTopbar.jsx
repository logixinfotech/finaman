import {
    Bell,
    Search,
    Plus,
    Moon,
} from "lucide-react";

export default function TaskTopbar() {
    return (
        <header className="tm-topbar">
            <div className="top-left">
                <h2>
                    Task Management
                </h2>
            </div>

            <div className="top-center">
                <div className="search-box">
                    <Search size={16} />

                    <input
                        type="text"
                        placeholder="Search tasks..."
                    />
                </div>
            </div>

            <div className="top-right">
                <button className="icon-btn">
                    <Bell size={18} />
                </button>

                <button className="icon-btn">
                    <Moon size={18} />
                </button>

                <button className="new-task-btn">
                    <Plus size={16} />
                    New Task
                </button>
            </div>
        </header>
    );
}