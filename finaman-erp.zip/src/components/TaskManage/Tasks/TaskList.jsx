export default function TaskList({
    tasks
}) {

    return (
        <div className="task-list">

            {tasks.map((task) => (

                <div
                    key={task.id}
                    className="list-row"
                >

                    <div>
                        <strong>
                            {task.title}
                        </strong>

                        <div>
                            {task.description}
                        </div>
                    </div>

                    <div>
                        {task.priority}
                    </div>

                    <div>
                        {task.status}
                    </div>

                    <div>
                        {task.assignee}
                    </div>

                </div>

            ))}

        </div>
    );
}