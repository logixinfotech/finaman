export default function TaskFilters({
    filter,
    setFilter,
}) {

    const filters = [
        "all",
        "todo",
        "inprogress",
        "done",
        "high"
    ];

    return (
        <div className="task-filters">

            {filters.map((item) => (
                <button
                    key={item}
                    className={
                        filter === item
                            ? "filter-btn active"
                            : "filter-btn"
                    }
                    onClick={() =>
                        setFilter(item)
                    }
                >
                    {item}
                </button>
            ))}

        </div>
    );
}