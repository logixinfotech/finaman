import TaskCard from "./TaskCard";

export default function TaskGrid({ tasks }) {
    return (
        <div className="task-grid">
            {tasks.map((task) => (
                <TaskCard
                    key={task.id}
                    task={task}
                />
            ))}
        </div>
    );
}