export default function TaskKanban({
    tasks
}) {

    const todo =
        tasks.filter(
            x => x.status === "todo"
        );

    const progress =
        tasks.filter(
            x => x.status === "inprogress"
        );

    const done =
        tasks.filter(
            x => x.status === "done"
        );

    return (
        <div className="kanban-board">

            <div className="kanban-column">

                <h3>
                    Todo
                </h3>

                {todo.map(task => (
                    <div
                        key={task.id}
                        className="kanban-card"
                    >
                        {task.title}
                    </div>
                ))}

            </div>

            <div className="kanban-column">

                <h3>
                    In Progress
                </h3>

                {progress.map(task => (
                    <div
                        key={task.id}
                        className="kanban-card"
                    >
                        {task.title}
                    </div>
                ))}

            </div>

            <div className="kanban-column">

                <h3>
                    Done
                </h3>

                {done.map(task => (
                    <div
                        key={task.id}
                        className="kanban-card"
                    >
                        {task.title}
                    </div>
                ))}

            </div>

        </div>
    );
}