export default function TaskCard({ task }) {
    return (
        <div className={`task-card priority-${task.priority.toLowerCase()}`}>

            <div className="task-card-header">

                <span
                    className={`priority-badge ${task.priority.toLowerCase()}`}
                >
                    {task.priority}
                </span>

                <span
                    className={`status-badge ${task.status}`}
                >
                    {task.status}
                </span>

            </div>

            <h3 className="task-title">
                {task.title}
            </h3>

            <p className="task-description">
                {task.description}
            </p>

            <div className="task-tags">
                {task.tags?.map((tag, index) => (
                    <span
                        key={index}
                        className="tag"
                    >
                        #{tag}
                    </span>
                ))}
            </div>

            <div className="task-footer">

                <div className="assignee-avatar">
                    {task.assignee?.charAt(0)}
                </div>

                <div className="task-meta">
                    <div>{task.assignee}</div>
                    <small>{task.project}</small>
                </div>

                <div className="task-date">
                    {task.dueDate}
                </div>

            </div>

        </div>
    );
}