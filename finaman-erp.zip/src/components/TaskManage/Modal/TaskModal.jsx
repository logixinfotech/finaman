import { useState } from "react";

export default function TaskModal({
    open,
    onClose,
    onSave
}) {

    const [task, setTask] =
        useState({
            title: "",
            description: "",
            priority: "Medium",
            status: "todo",
            assignee: "",
            project: "",
            dueDate: ""
        });

    if (!open) return null;

    const handleSave = () => {

        if (!task.title.trim()) {
            alert("Task Title Required");
            return;
        }

        onSave({
            id: Date.now(),
            ...task,
            tags: []
        });

        setTask({
            title: "",
            description: "",
            priority: "Medium",
            status: "todo",
            assignee: "",
            project: "",
            dueDate: ""
        });

        onClose();
    };

    return (
        <div className="modal-overlay">

            <div className="task-modal">

                <div className="modal-header">
                    <h2>New Task</h2>

                    <button
                        onClick={onClose}
                    >
                        ✕
                    </button>
                </div>

                <div className="modal-body">

                    <input
                        type="text"
                        placeholder="Task Title"
                        value={task.title}
                        onChange={(e) =>
                            setTask({
                                ...task,
                                title: e.target.value
                            })
                        }
                    />

                    <textarea
                        placeholder="Description"
                        value={task.description}
                        onChange={(e) =>
                            setTask({
                                ...task,
                                description:
                                    e.target.value
                            })
                        }
                    />

                    <select
                        value={task.priority}
                        onChange={(e) =>
                            setTask({
                                ...task,
                                priority:
                                    e.target.value
                            })
                        }
                    >
                        <option>High</option>
                        <option>Medium</option>
                        <option>Low</option>
                    </select>

                    <select
                        value={task.status}
                        onChange={(e) =>
                            setTask({
                                ...task,
                                status:
                                    e.target.value
                            })
                        }
                    >
                        <option value="todo">
                            Todo
                        </option>

                        <option value="inprogress">
                            In Progress
                        </option>

                        <option value="done">
                            Done
                        </option>
                    </select>

                    <input
                        type="text"
                        placeholder="Assignee"
                        value={task.assignee}
                        onChange={(e) =>
                            setTask({
                                ...task,
                                assignee:
                                    e.target.value
                            })
                        }
                    />

                    <input
                        type="text"
                        placeholder="Project"
                        value={task.project}
                        onChange={(e) =>
                            setTask({
                                ...task,
                                project:
                                    e.target.value
                            })
                        }
                    />

                    <input
                        type="date"
                        value={task.dueDate}
                        onChange={(e) =>
                            setTask({
                                ...task,
                                dueDate:
                                    e.target.value
                            })
                        }
                    />

                </div>

                <div className="modal-footer">

                    <button
                        className="btn-cancel"
                        onClick={onClose}
                    >
                        Cancel
                    </button>

                    <button
                        className="btn-save"
                        onClick={handleSave}
                    >
                        Save Task
                    </button>

                </div>

            </div>

        </div>
    );
}