import { useState, useEffect, useCallback, useMemo } from "react";
import {
  fetchWorkDiaries, createWorkDiary, updateWorkDiary,
  deleteWorkDiary, getActledList, fetchYesterdayTasks,
} from "../../utils/api";
import { alertError, confirmDelete, showToast } from "../Reusable/alert";
import WorkDiaryForm from "./WorkDiaryForm";

// ── Design tokens ─────────────────────────────────────────────────────────────
export const D = {
  bgDeep:"#0a0c10", bgPanel:"#111318", bgCard:"#181c24", bgHover:"#1e2330",
  border:"#252a38", borderLit:"#2e3448",
  accent:"#185FA5", accentGlow:"rgba(24,95,165,0.35)",
  textPri:"#eef0f5", textSec:"#8892a4", textMuted:"#4d5566",
  green:"#06d6a0", purple:"#7c6fff", red:"#ff4d6d", amber:"#ffd166",
};

const NAV = [
  { key:"all",       label:"All Diaries",  icon:<SvgIcon d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z"/> },
  { key:"Draft",     label:"Drafts",       icon:<SvgIcon d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>, badgeKey:"Draft"    },
  { key:"Submitted", label:"Submitted",    icon:<SvgIcon d="M22 2L11 13M22 2L15 22 11 13 2 9 22 2"/>,               badgeKey:"Submitted" },
  { key:"Approved",  label:"Approved",     icon:<SvgIcon d="M20 6L9 17 4 12"/>,                                      badgeKey:"Approved"  },
  { key:"Rejected",  label:"Rejected",     icon:<SvgIcon d="M10 10L14 14M10 14L14 10"/>,                            badgeKey:"Rejected"  },
];

const STATUS_BORDER = { Draft:"#4d5566", Submitted:"#7c6fff", Approved:"#06d6a0", Rejected:"#ff4d6d" };
const STATUS_BADGE  = {
  Draft:     { bg:"rgba(77,85,102,0.2)",   color:"#8892a4" },
  Submitted: { bg:"rgba(124,111,255,0.15)",color:"#7c6fff" },
  Approved:  { bg:"rgba(6,214,160,0.15)",  color:"#06d6a0" },
  Rejected:  { bg:"rgba(255,77,109,0.15)", color:"#ff4d6d" },
};

function SvgIcon({ d, size=15 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
      <path d={d}/>
    </svg>
  );
}

const initials = (n="") => n.split(" ").slice(0,2).map(w=>w[0]?.toUpperCase()||"").join("");
const avGrads = [
  "linear-gradient(135deg,#185FA5,#7c6fff)",
  "linear-gradient(135deg,#06d6a0,#185FA5)",
  "linear-gradient(135deg,#7c6fff,#ff4d6d)",
  "linear-gradient(135deg,#ffd166,#185FA5)",
];
const avGrad = (n="") => { let h=0; for(let i=0;i<n.length;i++) h=n.charCodeAt(i)+((h<<5)-h); return avGrads[Math.abs(h)%avGrads.length]; };

const initialForm = {
  diary_id:null, employee_id:"", employee_name:"", department:"",
  diary_date:"", period_type:"Daily", diary_status:"Draft",
  notes:"", manager_remarks:"", task_lines:[],
};

// ═══════════════════════════════════════════════════════════════════════════════
const WorkDiary = ({ tab }) => {
  const [list,      setList]      = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [employees, setEmployees] = useState([]);
  const [activeNav, setActiveNav] = useState("all");
  const [selected,  setSelected]  = useState(null);
  const [formMode,  setFormMode]  = useState("view");
  const [formData,  setFormData]  = useState(initialForm);
  const [saving,    setSaving]    = useState(false);

  const loadList = useCallback(async () => {
    try {
      setLoading(true);
      const d = await fetchWorkDiaries();
      setList(Array.isArray(d)?d:d?.data||[]);
    } catch { alertError("Error","Failed to load diaries"); }
    finally  { setLoading(false); }
  }, []);

  useEffect(() => {
    loadList();
    getActledList().then(r=>setEmployees(Array.isArray(r)?r:r?.data||[])).catch(()=>{});
  }, []);

  const badges = useMemo(() => {
    const c={}; list.forEach(d=>{const s=d.diary_status||"Draft";c[s]=(c[s]||0)+1;}); return c;
  }, [list]);

  const filtered = useMemo(() =>
    activeNav==="all" ? list : list.filter(d=>(d.diary_status||"Draft")===activeNav),
  [list,activeNav]);

  const handleSelect = r => { setSelected(r); setFormData({...initialForm,...r}); setFormMode("view"); };
  const handleAdd    = () => { setSelected(null); setFormData({...initialForm}); setFormMode("add"); };

  const handleSave = async (data) => {
    try {
      setSaving(true);
      const res = formMode==="edit" && data.diary_id
        ? await updateWorkDiary(data.diary_id,data)
        : await createWorkDiary(data);
      if (res?.success) {
        showToast({icon:"success",title:formMode==="edit"?"Diary updated":"Diary created"});
        await loadList();
        const newId = res.data?.diary_id || data.diary_id;
        if (newId) {
          const fl = await fetchWorkDiaries();
          const all = Array.isArray(fl)?fl:fl?.data||[];
          const found = all.find(d=>d.diary_id===newId);
          if (found) { setSelected(found); setFormData({...initialForm,...found}); }
        }
        setFormMode("view");
      }
    } catch { alertError("Error","Failed to save diary"); }
    finally  { setSaving(false); }
  };

  const handleDelete = async (row) => {
    if (!await confirmDelete({title:`Delete diary for "${row.employee_name}" on ${row.diary_date}?`})) return;
    const res = await deleteWorkDiary(row.diary_id);
    if (res?.success) {
      showToast({icon:"success",title:"Deleted"});
      setSelected(null); setFormData(initialForm); setFormMode("view"); loadList();
    }
  };

  const handleCopyYesterday = useCallback(async () => {
    if (!formData.employee_id || !formData.diary_date) return;
    try {
      const y = new Date(formData.diary_date); y.setDate(y.getDate()-1);
      const res = await fetchYesterdayTasks(formData.employee_id, y.toISOString().slice(0,10));
      const tasks = Array.isArray(res)?res:res?.data||[];
      if (!tasks.length) { showToast({icon:"info",title:"No tasks for yesterday"}); return; }
      const copied = tasks.map(t=>({...t,_key:crypto.randomUUID(),line_id:undefined,diary_id:undefined,actual_time:"",status:"Pending"}));
      setFormData(p=>({...p,task_lines:copied}));
      showToast({icon:"success",title:`${copied.length} task(s) copied`});
    } catch { alertError("Error","Failed to copy yesterday's tasks"); }
  }, [formData.employee_id,formData.diary_date]);

  return (
    <div style={{display:"flex",height:"100vh",overflow:"hidden",background:D.bgDeep,fontFamily:"'DM Sans','Inter',system-ui,sans-serif"}}>

      {/* ══════ SIDEBAR ══════ */}
      <aside style={{width:240,background:D.bgPanel,borderRight:`1px solid ${D.border}`,display:"flex",flexDirection:"column",padding:"24px 14px 20px",flexShrink:0}}>

        {/* Logo */}
        <div style={{display:"flex",alignItems:"center",gap:10,padding:"0 8px 22px"}}>
          <div style={{width:34,height:34,borderRadius:8,background:D.accent,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,boxShadow:`0 0 18px ${D.accentGlow}`}}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5">
              <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/>
              <rect x="9" y="3" width="6" height="4" rx="1"/>
              <path d="M9 12h6M9 16h4"/>
            </svg>
          </div>
          <div>
            <div style={{fontWeight:800,fontSize:15,color:D.textPri,letterSpacing:-0.4,lineHeight:1.2}}>
              Work<span style={{color:"#378ADD"}}>Diary</span>
            </div>
            <div style={{fontSize:10,color:D.textMuted,marginTop:2}}>FINAMANERP · Payroll</div>
          </div>
        </div>

        <SideLabel>Menu</SideLabel>
        {NAV.map(item=>(
          <SideItem key={item.key} label={item.label} icon={item.icon}
            active={activeNav===item.key} badge={item.badgeKey?badges[item.badgeKey]:null}
            onClick={()=>setActiveNav(item.key)} />
        ))}

        <div style={{height:1,background:D.border,margin:"12px 0"}}/>
        <SideLabel>Quick Actions</SideLabel>
        <SideItem label="New Diary Entry" active={formMode==="add"&&!selected} onClick={handleAdd}
          icon={<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>}
        />

        <div style={{flex:1}}/>
        <div style={{paddingTop:16,borderTop:`1px solid ${D.border}`}}>
          <div style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:8,background:D.bgCard}}>
            <div style={{width:32,height:32,borderRadius:"50%",background:avGrad(employees[0]?.emp_name||""),display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,color:"#fff",flexShrink:0}}>
              {initials(employees[0]?.emp_name||"YO")}
            </div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:12,fontWeight:600,color:D.textPri,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                {employees[0]?.emp_name||"You"}
              </div>
              <div style={{fontSize:10,color:D.textMuted,marginTop:1}}>Payroll Staff</div>
            </div>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={D.textMuted} strokeWidth="2" style={{cursor:"pointer",flexShrink:0}}>
              <circle cx="12" cy="5" r="1" fill={D.textMuted}/>
              <circle cx="12" cy="12" r="1" fill={D.textMuted}/>
              <circle cx="12" cy="19" r="1" fill={D.textMuted}/>
            </svg>
          </div>
        </div>
      </aside>

      {/* ══════ DIARY LIST ══════ */}
      <div style={{width:290,background:D.bgPanel,borderRight:`1px solid ${D.border}`,display:"flex",flexDirection:"column",overflow:"hidden",flexShrink:0}}>
        <div style={{padding:"14px 14px 10px",borderBottom:`1px solid ${D.border}`,flexShrink:0}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
            <span style={{fontWeight:700,fontSize:13,color:D.textPri}}>
              {NAV.find(n=>n.key===activeNav)?.label||"All Diaries"}
            </span>
            <span style={{fontSize:10,fontWeight:700,color:D.textSec,background:D.bgHover,border:`1px solid ${D.border}`,padding:"2px 8px",borderRadius:20}}>
              {filtered.length}
            </span>
          </div>
          <button onClick={handleAdd} style={{
            width:"100%",height:34,borderRadius:8,background:D.accent,color:"#fff",
            border:"none",cursor:"pointer",fontSize:12,fontWeight:600,
            display:"flex",alignItems:"center",justifyContent:"center",gap:6,
            boxShadow:`0 0 14px ${D.accentGlow}`,transition:"background 0.15s",
          }}
            onMouseEnter={e=>e.currentTarget.style.background="#0C447C"}
            onMouseLeave={e=>e.currentTarget.style.background=D.accent}
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
            New Diary Entry
          </button>
        </div>

        <div style={{flex:1,overflowY:"auto",padding:"6px 8px 12px",scrollbarWidth:"thin",scrollbarColor:`${D.borderLit} transparent`}}>
          {loading ? [...Array(5)].map((_,i)=>(
            <div key={i} style={{height:80,borderRadius:10,background:D.bgCard,margin:"4px 0",opacity:0.6}}/>
          )) : filtered.length===0 ? (
            <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:"40px 0",gap:10,color:D.textMuted}}>
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg>
              <span style={{fontSize:12}}>No diaries found</span>
            </div>
          ) : filtered.map(row=>(
            <DiaryCard key={row.diary_id} row={row}
              selected={selected?.diary_id===row.diary_id}
              onClick={()=>handleSelect(row)} />
          ))}
        </div>
      </div>

      {/* ══════ FORM AREA ══════ */}
      <div style={{flex:1,overflow:"hidden",background:D.bgDeep}}>
        {(selected||formMode==="add") ? (
          <WorkDiaryForm
            formData={formData} setFormData={setFormData}
            mode={formMode} saving={saving}
            onSave={handleSave}
            onDelete={()=>selected&&handleDelete(selected)}
            onCancel={()=>{
              if(formMode==="add"){setSelected(null);setFormMode("view");}
              else{setFormData({...initialForm,...selected});setFormMode("view");}
            }}
            onModify={()=>setFormMode("edit")}
            onEditCancel={()=>{setFormData({...initialForm,...selected});setFormMode("view");}}
            onNewEntry={handleAdd}
            currentRecord={selected?filtered.findIndex(d=>d.diary_id===selected.diary_id)+1:0}
            totalRecords={filtered.length}
            rights={{add:1,edit:1,delete:1}}
            employees={employees}
            onCopyYesterday={handleCopyYesterday}
          />
        ) : (
          <EmptyArea onAdd={handleAdd} />
        )}
      </div>

    </div>
  );
};

// ── Sub-components ─────────────────────────────────────────────────────────────
const SideLabel = ({children}) => (
  <div style={{fontSize:9.5,fontWeight:600,letterSpacing:"1.8px",textTransform:"uppercase",color:D.textMuted,padding:"10px 10px 4px"}}>
    {children}
  </div>
);

const SideItem = ({label,icon,active,badge,onClick}) => {
  const [hov,setHov]=useState(false);
  return (
    <div onClick={onClick} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{
        display:"flex",alignItems:"center",gap:10,padding:"9px 12px",borderRadius:8,
        cursor:"pointer",fontSize:13,fontWeight:500,position:"relative",
        color:active?"#378ADD":hov?D.textPri:D.textSec,
        background:active?"rgba(24,95,165,0.13)":hov?D.bgHover:"transparent",
        transition:"all 0.15s",userSelect:"none",
      }}
    >
      {active&&<span style={{position:"absolute",left:0,top:"20%",width:3,height:"60%",background:"#378ADD",borderRadius:"0 3px 3px 0"}}/>}
      <span style={{width:18,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>{icon}</span>
      <span style={{flex:1}}>{label}</span>
      {badge>0&&<span style={{background:D.accent,color:"#fff",fontSize:10,fontWeight:700,padding:"1px 7px",borderRadius:20,minWidth:20,textAlign:"center"}}>{badge}</span>}
    </div>
  );
};

const DiaryCard = ({row,selected,onClick}) => {
  const [hov,setHov]=useState(false);
  const s = row.diary_status||"Draft";
  const badge = STATUS_BADGE[s]||STATUS_BADGE.Draft;
  return (
    <div onClick={onClick} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{
        margin:"3px 0",padding:"11px 13px",borderRadius:10,cursor:"pointer",
        background:selected?"rgba(24,95,165,0.1)":hov?D.bgHover:D.bgCard,
        border:`1px solid ${selected?"#185FA5":hov?D.borderLit:D.border}`,
        borderLeft:`3px solid ${STATUS_BORDER[s]||D.textMuted}`,
        transition:"all 0.15s",
      }}
    >
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:6}}>
        <span style={{fontSize:12,fontWeight:600,color:D.textPri}}>{row.diary_date||"—"}</span>
        <span style={{fontSize:10,fontWeight:600,padding:"2px 8px",borderRadius:20,background:badge.bg,color:badge.color}}>{s}</span>
      </div>
      <div style={{display:"flex",alignItems:"center",gap:7}}>
        <div style={{width:20,height:20,borderRadius:"50%",background:avGrad(row.employee_name||""),display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:700,color:"#fff",flexShrink:0}}>
          {initials(row.employee_name||"?")}
        </div>
        <span style={{fontSize:11.5,color:D.textSec,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
          {row.employee_name||"—"}
        </span>
      </div>
      <div style={{display:"flex",justifyContent:"space-between",marginTop:7}}>
        <span style={{fontSize:10,color:D.textMuted}}>{row.department||""}</span>
        <span style={{fontSize:10,color:D.textMuted}}>{row.task_count??0} tasks</span>
      </div>
    </div>
  );
};

const EmptyArea = ({onAdd}) => (
  <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:16,color:D.textMuted,position:"relative"}}>
    <div style={{position:"absolute",width:400,height:400,borderRadius:"50%",background:D.accent,filter:"blur(130px)",opacity:0.05,pointerEvents:"none"}}/>
    <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="0.8">
      <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/>
      <rect x="9" y="3" width="6" height="4" rx="1"/>
      <path d="M9 12h6M9 16h4"/>
    </svg>
    <div style={{textAlign:"center"}}>
      <div style={{fontSize:14,fontWeight:600,color:D.textSec,marginBottom:6}}>Select a diary to view</div>
      <div style={{fontSize:12,color:D.textMuted}}>or create a new entry</div>
    </div>
    <button onClick={onAdd} style={{marginTop:8,height:36,padding:"0 22px",fontSize:13,fontWeight:600,background:D.accent,color:"#fff",border:"none",borderRadius:8,cursor:"pointer",boxShadow:`0 0 18px ${D.accentGlow}`}}>
      + New Diary Entry
    </button>
  </div>
);

export default WorkDiary;
