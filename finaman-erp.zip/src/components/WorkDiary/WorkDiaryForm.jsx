import React, { useState, useEffect, useCallback, useRef ,useMemo} from "react";
import ERPHeader from "../Reusable/form/HeaderForm";
import ERPFooter from "../Reusable/form/FooterForm";
import ERPAutocomplete from "../Reusable/input/ERPAutocomplete";
import ERPDateInput from "../Reusable/input/Date"; 
// ─── Constants ────────────────────────────────────────────────────────────────
const FONT = `'Inter','Tahoma',system-ui,sans-serif`;

const PRIORITY_OPTIONS  = ["High", "Medium", "Low"];
const CATEGORY_OPTIONS  = ["Development","Testing","Meeting","Review","Support","Documentation","Other"];
const STATUS_OPTIONS    = ["Pending","In Progress","Completed","Cancelled"];

const PRIORITY_CFG = {
  High:   { dot:"bg-[#E24B4A]", badge:"bg-[#FCEBEB] text-[#791F1F]",  border:"border-l-[#E24B4A]" },
  Medium: { dot:"bg-[#EF9F27]", badge:"bg-[#FAEEDA] text-[#633806]",  border:"border-l-[#EF9F27]" },
  Low:    { dot:"bg-[#639922]", badge:"bg-[#EAF3DE] text-[#27500A]",  border:"border-l-[#639922]" },
};

const STATUS_CFG = {
  Pending:       "bg-[#F1EFE8] text-[#444441]",
  "In Progress": "bg-[#E6F1FB] text-[#0C447C]",
  Completed:     "bg-[#EAF3DE] text-[#27500A]",
  Cancelled:     "bg-[#FCEBEB] text-[#791F1F]",
  Submitted:     "bg-[#EEEDFE] text-[#3C3489]",
  Approved:      "bg-[#EAF3DE] text-[#27500A]",
  Rejected:      "bg-[#FCEBEB] text-[#791F1F]",
  Draft:         "bg-[#F1EFE8] text-[#444441]",
};

const CATEGORY_COLORS = {
  Development:   "bg-[#E6F1FB] text-[#0C447C]",
  Testing:       "bg-[#EEEDFE] text-[#3C3489]",
  Meeting:       "bg-[#FAEEDA] text-[#633806]",
  Review:        "bg-[#EAF3DE] text-[#27500A]",
  Support:       "bg-[#FCEBEB] text-[#791F1F]",
  Documentation: "bg-[#F1EFE8] text-[#444441]",
  Other:         "bg-slate-100 text-slate-500",
};

const newTask = () => ({
  _key: crypto.randomUUID(),
  work_plan: "", target: "", priority: "Medium",
  category: "Development", expected_time: "",
  actual_time: "", status: "Pending", due_date: "",
  remarks: "", assigned_by: null,
});

// ─── Tiny helpers ─────────────────────────────────────────────────────────────
const fmtHrs  = (v) => { const n = parseFloat(v); return isNaN(n) ? "0.0" : n.toFixed(1); };
const fmtDate = (d) => {
  if (!d) return "—";
  const date  = new Date(d + "T00:00:00");
  const today = new Date(); today.setHours(0,0,0,0);
  const diff  = Math.round((date - today) / 86400000);
  if (diff === 0)  return "Today";
  if (diff === 1)  return "Tomorrow";
  if (diff === -1) return "Yesterday";
  if (diff < 0)    return `${Math.abs(diff)}d overdue`;
  if (diff <= 7)   return `In ${diff}d`;
  return date.toLocaleDateString("en-IN", { day:"numeric", month:"short" });
};
const initials = (n="") => n.split(" ").slice(0,2).map(w=>w[0]?.toUpperCase()||"").join("");
const AV_COLORS = [
  "bg-[#E6F1FB] text-[#0C447C]","bg-[#EAF3DE] text-[#27500A]",
  "bg-[#EEEDFE] text-[#3C3489]","bg-[#FAEEDA] text-[#633806]",
];
const avColor = (n="") => { let h=0; for(let i=0;i<n.length;i++) h=n.charCodeAt(i)+((h<<5)-h); return AV_COLORS[Math.abs(h)%AV_COLORS.length]; };

// ─── Sub-components ───────────────────────────────────────────────────────────
const Pill = ({ label, cls }) => (
  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium ${cls}`}>{label}</span>
);

const PrioDot = ({ p }) => (
  <span className={`inline-block w-2 h-2 rounded-full shrink-0 ${(PRIORITY_CFG[p]||PRIORITY_CFG.Medium).dot}`} />
);

const Avatar = ({ name, size = "w-7 h-7 text-[10px]" }) => {
  const c = avColor(name);
  return <div className={`${size} rounded-full flex items-center justify-center font-semibold shrink-0 ${c}`}>{initials(name)}</div>;
};

const StatCard = ({ icon, value, label, sub, accent }) => (
  <div className={`bg-white border border-slate-200 rounded-xl p-4 flex flex-col gap-2 relative overflow-hidden
    hover:border-slate-300 hover:-translate-y-0.5 transition-all`}>
    <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${accent}`}>
      {icon}
    </div>
    <div className="text-[26px] font-bold text-slate-800 leading-none">{value}</div>
    <div className="text-[12px] text-slate-400 font-medium">{label}</div>
    <div className="text-[11px] text-slate-500">{sub}</div>
    <div className={`absolute bottom-0 left-0 right-0 h-[3px] ${accent.replace("bg-[","bg-[").split(" ")[0]}`} />
  </div>
);

// ─── Task Card (grid view) ────────────────────────────────────────────────────
const TaskCard = ({ task, onOpen, onToggleDone, onDelete }) => {
  const p       = PRIORITY_CFG[task.priority] || PRIORITY_CFG.Medium;
  const isDone  = task.status === "Completed";
  const isOver  = task.due_date && task.status !== "Completed" && task.status !== "Cancelled"
    && new Date(task.due_date + "T00:00:00") < new Date();

  return (
    <div
      onClick={() => onOpen(task._key)}
      onContextMenu={(e) => { e.preventDefault(); onOpen(task._key); }}
      className={`bg-white border border-slate-200 rounded-xl p-4 flex flex-col gap-3 cursor-pointer
        hover:border-[#85B7EB] hover:-translate-y-0.5 hover:shadow-md transition-all
        border-l-4 ${p.border} ${isDone ? "opacity-60" : ""}`}
    >
      {/* Top row */}
      <div className="flex items-start gap-2">
        <button
          onClick={(e) => { e.stopPropagation(); onToggleDone(task._key); }}
          className={`w-[18px] h-[18px] rounded-[5px] border-2 shrink-0 mt-0.5 flex items-center justify-center transition-all
            ${isDone ? "bg-[#639922] border-[#639922]" : "border-slate-300 hover:border-[#185FA5]"}`}
        >
          {isDone && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>}
        </button>
        <div className="flex-1 min-w-0">
          <div className={`text-[13px] font-semibold text-slate-800 leading-snug ${isDone ? "line-through text-slate-400" : ""}`}>
            {task.work_plan || "Untitled task"}
          </div>
          {task.target && (
            <div className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">{task.target}</div>
          )}
        </div>
      </div>

      {/* Meta */}
      <div className="flex items-center gap-1.5 flex-wrap">
        <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold ${p.badge}`}>
          <PrioDot p={task.priority} />{task.priority}
        </span>
        <Pill label={task.category} cls={CATEGORY_COLORS[task.category] || "bg-slate-100 text-slate-500"} />
        <Pill label={task.status} cls={STATUS_CFG[task.status] || STATUS_CFG.Pending} />
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-1 border-t border-slate-100">
        <span className={`text-[11px] font-medium ${isOver ? "text-[#A32D2D]" : "text-slate-400"}`}>
          {isOver ? "⚠ " : ""}
          {fmtDate(task.due_date)}
        </span>
        <div className="flex items-center gap-2 text-[11px] text-slate-400">
          <span>{fmtHrs(task.expected_time)}h exp</span>
          {task.actual_time && (
            <span className={parseFloat(task.actual_time) > parseFloat(task.expected_time) ? "text-[#854F0B] font-medium" : ""}>
              · {fmtHrs(task.actual_time)}h act
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

// ─── Task Row (list view) ─────────────────────────────────────────────────────
const TaskRow = ({ task, onOpen, onToggleDone, onDelete }) => {
  const p      = PRIORITY_CFG[task.priority] || PRIORITY_CFG.Medium;
  const isDone = task.status === "Completed";
  const isOver = task.due_date && task.status !== "Completed" && task.status !== "Cancelled"
    && new Date(task.due_date + "T00:00:00") < new Date();

  return (
    <div
      onClick={() => onOpen(task._key)}
      className={`flex items-center gap-3 bg-white border border-slate-200 rounded-xl px-4 py-3 cursor-pointer
        hover:border-[#85B7EB] hover:shadow-sm transition-all border-l-4 ${p.border}
        ${isDone ? "opacity-60" : ""}`}
    >
      <button
        onClick={(e) => { e.stopPropagation(); onToggleDone(task._key); }}
        className={`w-[18px] h-[18px] rounded-[5px] border-2 shrink-0 flex items-center justify-center transition-all
          ${isDone ? "bg-[#639922] border-[#639922]" : "border-slate-300 hover:border-[#185FA5]"}`}
      >
        {isDone && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>}
      </button>

      <div className="flex-[2] min-w-0">
        <div className={`text-[13px] font-medium text-slate-800 truncate ${isDone ? "line-through text-slate-400" : ""}`}>
          {task.work_plan || "Untitled task"}
        </div>
        {task.target && <div className="text-[11px] text-slate-400 truncate">{task.target}</div>}
      </div>

      <span className={`hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold shrink-0 ${p.badge}`}>
        <PrioDot p={task.priority} />{task.priority}
      </span>
      <Pill label={task.category} cls={`hidden md:inline-flex shrink-0 ${CATEGORY_COLORS[task.category] || ""}`} />
      <Pill label={task.status}   cls={`shrink-0 ${STATUS_CFG[task.status] || STATUS_CFG.Pending}`} />

      <span className={`text-[11px] shrink-0 w-20 text-right ${isOver ? "text-[#A32D2D] font-medium" : "text-slate-400"}`}>
        {isOver ? "⚠ " : ""}{fmtDate(task.due_date)}
      </span>
      <span className="text-[11px] text-slate-400 shrink-0 w-16 text-right tabular-nums">
        {fmtHrs(task.expected_time)}h
      </span>

      <button
        onClick={(e) => { e.stopPropagation(); onDelete(task._key); }}
        className="shrink-0 p-1 rounded-md opacity-0 group-hover:opacity-100 hover:bg-[#FCEBEB] hover:text-[#A32D2D] text-slate-300 transition-all"
      >
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
          <path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
        </svg>
      </button>
    </div>
  );
};

// ─── Detail Panel ─────────────────────────────────────────────────────────────
const DetailPanel = ({ task, onClose, onEdit, onDelete, onToggleDone, isViewMode }) => {
  const [comment, setComment] = useState("");
  const [comments, setComments] = useState(task?.comments || []);
  if (!task) return null;

  const p      = PRIORITY_CFG[task.priority] || PRIORITY_CFG.Medium;
  const isDone = task.status === "Completed";
  const isOver = task.due_date && task.status !== "Completed" && task.status !== "Cancelled"
    && new Date(task.due_date + "T00:00:00") < new Date();

  const addComment = () => {
    if (!comment.trim()) return;
    const c = { author: "You", text: comment, time: new Date().toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" }) };
    setComments(prev => [...prev, c]);
    setComment("");
  };

  return (
    <div className="w-[320px] xl:w-[360px] shrink-0 bg-white border-l border-slate-200 flex flex-col overflow-hidden h-full">
      {/* Header */}
      <div className={`px-4 pt-4 pb-3 border-b border-slate-100 border-l-4 ${p.border}`}>
        <div className="flex items-center gap-2 mb-2">
          <Pill label={task.priority}  cls={`${p.badge}`} />
          <Pill label={task.status}    cls={STATUS_CFG[task.status] || STATUS_CFG.Pending} />
          {isOver && <Pill label="Overdue" cls="bg-[#FCEBEB] text-[#791F1F]" />}
          <button onClick={onClose} className="ml-auto p-1 rounded-md hover:bg-slate-100 text-slate-400 transition-colors">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
        <div className={`text-[15px] font-semibold text-slate-800 leading-snug ${isDone ? "line-through text-slate-400" : ""}`}>
          {task.work_plan || "Untitled task"}
        </div>
        {task.target && (
          <div className="text-[12px] text-slate-500 mt-1 leading-relaxed">{task.target}</div>
        )}
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">

        {/* Fields */}
        <div className="flex flex-col gap-2">
          {[
            { label: "Category",  val: task.category  },
            { label: "Due date",  val: fmtDate(task.due_date), red: isOver },
            { label: "Exp. hrs",  val: `${fmtHrs(task.expected_time)}h`   },
            { label: "Actual hrs",val: task.actual_time ? `${fmtHrs(task.actual_time)}h` : "—",
              amber: parseFloat(task.actual_time) > parseFloat(task.expected_time) },
          ].map(({ label, val, red, amber }) => (
            <div key={label} className="flex items-center justify-between text-[12px] py-1 border-b border-slate-50">
              <span className="text-slate-400 font-medium">{label}</span>
              <span className={`font-medium ${red ? "text-[#A32D2D]" : amber ? "text-[#854F0B]" : "text-slate-700"}`}>{val}</span>
            </div>
          ))}
        </div>

        {/* Remarks */}
        {task.remarks && (
          <div>
            <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2">Remarks</div>
            <div className="text-[12px] text-slate-600 bg-slate-50 border border-slate-100 rounded-lg p-3 leading-relaxed">
              {task.remarks}
            </div>
          </div>
        )}

        {/* Comments */}
        <div>
          <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Comments {comments.length > 0 && `(${comments.length})`}
          </div>
          <div className="flex flex-col gap-3 mb-3">
            {comments.length === 0 ? (
              <div className="text-[11px] text-slate-300">No comments yet</div>
            ) : comments.map((c, i) => (
              <div key={i} className="flex gap-2">
                <Avatar name={c.author} size="w-6 h-6 text-[9px]" />
                <div className="flex-1">
                  <div className="text-[11px] font-medium text-slate-600">
                    {c.author} <span className="text-slate-300 font-normal ml-1">{c.time}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 leading-relaxed mt-0.5">{c.text}</div>
                </div>
              </div>
            ))}
          </div>
          {!isViewMode && (
            <div className="flex gap-2">
              <input
                value={comment}
                onChange={e => setComment(e.target.value)}
                onKeyDown={e => e.key === "Enter" && addComment()}
                placeholder="Add a comment..."
                className="flex-1 h-8 px-2.5 text-[12px] border border-slate-200 rounded-lg outline-none focus:border-[#378ADD] bg-white"
              />
              <button onClick={addComment}
                className="h-8 px-2.5 border border-slate-200 rounded-lg text-slate-500 hover:bg-slate-50 transition-colors">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
                </svg>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Footer actions */}
      <div className="px-4 py-3 border-t border-slate-100 flex gap-2">
        <button onClick={() => onToggleDone(task._key)}
          className={`flex-1 flex items-center justify-center gap-1.5 h-8 text-[12px] font-medium rounded-lg transition-colors border
            ${isDone
              ? "bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100"
              : "bg-[#EAF3DE] text-[#27500A] border-[#C0DD97] hover:bg-[#C0DD97]"}`}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          {isDone ? "Reopen" : "Complete"}
        </button>
        {!isViewMode && (
          <>
            <button onClick={onEdit}
              className="flex-1 flex items-center justify-center gap-1.5 h-8 text-[12px] font-medium rounded-lg
                border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 transition-colors">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
              </svg>
              Edit
            </button>
            <button onClick={() => onDelete(task._key)}
              className="h-8 px-3 rounded-lg border border-[#F7C1C1] bg-[#FCEBEB] text-[#791F1F]
                text-[12px] hover:bg-[#F7C1C1] transition-colors">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="3 6 5 6 21 6"/>
                <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
              </svg>
            </button>
          </>
        )}
      </div>
    </div>
  );
};

// ─── Add / Edit Modal ─────────────────────────────────────────────────────────
const TaskModal = ({ task, onClose, onSave }) => {
  const isEdit = !!task?._key && !!task?.work_plan;
  const [form, setForm] = useState(() => task ? { ...task } : newTask());
  const set = (f, v) => setForm(p => ({ ...p, [f]: v }));

  const Field = ({ label, req, children }) => (
    <div className="flex flex-col gap-1">
      <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
        {label}{req && <span className="text-red-500 ml-0.5">*</span>}
      </label>
      {children}
    </div>
  );

  const inp = "w-full h-9 px-3 text-[13px] border border-slate-200 rounded-lg outline-none focus:border-[#378ADD] bg-white";
  const sel = "w-full h-9 px-3 text-[13px] border border-slate-200 rounded-lg outline-none focus:border-[#378ADD] bg-white";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/30 backdrop-blur-sm">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-[480px] shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-100">
          <div className="w-7 h-7 rounded-lg bg-[#E6F1FB] flex items-center justify-center">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#185FA5" strokeWidth="2.5">
              {isEdit
                ? <><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></>
                : <><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>}
            </svg>
          </div>
          <span className="text-[14px] font-semibold text-slate-800">{isEdit ? "Edit Task" : "Add New Task"}</span>
          <button onClick={onClose} className="ml-auto p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 transition-colors">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="p-5 flex flex-col gap-4 overflow-y-auto max-h-[70vh]">
          <Field label="Work plan / task" req>
            <input value={form.work_plan} onChange={e => set("work_plan", e.target.value)}
              placeholder="e.g. Fix login redirect bug..."
              className={inp} autoFocus />
          </Field>
          <Field label="Target / expected output">
            <textarea value={form.target} onChange={e => set("target", e.target.value)}
              placeholder="What should be delivered..."
              rows={2}
              className="w-full px-3 py-2 text-[13px] border border-slate-200 rounded-lg outline-none focus:border-[#378ADD] bg-white resize-none" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Priority">
              <select value={form.priority} onChange={e => set("priority", e.target.value)} className={sel}>
                {PRIORITY_OPTIONS.map(o => <option key={o}>{o}</option>)}
              </select>
            </Field>
            <Field label="Status">
              <select value={form.status} onChange={e => set("status", e.target.value)} className={sel}>
                {STATUS_OPTIONS.map(o => <option key={o}>{o}</option>)}
              </select>
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Category">
              <select value={form.category} onChange={e => set("category", e.target.value)} className={sel}>
                {CATEGORY_OPTIONS.map(o => <option key={o}>{o}</option>)}
              </select>
            </Field>
            <Field label="Due date">
              <input type="date" value={form.due_date} onChange={e => set("due_date", e.target.value)} className={inp} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Expected hrs">
              <input type="text" value={form.expected_time}
                onChange={e => set("expected_time", e.target.value.replace(/[^0-9.]/g,""))}
                placeholder="e.g. 2.5" className={inp} />
            </Field>
            <Field label="Actual hrs">
              <input type="text" value={form.actual_time}
                onChange={e => set("actual_time", e.target.value.replace(/[^0-9.]/g,""))}
                placeholder="e.g. 3" className={inp} />
            </Field>
          </div>
          <Field label="Remarks">
            <input value={form.remarks} onChange={e => set("remarks", e.target.value)}
              placeholder="Any notes or blockers..." className={inp} />
          </Field>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 px-5 py-4 border-t border-slate-100">
          <button onClick={onClose}
            className="h-9 px-4 text-[13px] font-medium border border-slate-200 rounded-lg text-slate-600
              hover:bg-slate-50 transition-colors">
            Cancel
          </button>
          <button onClick={() => { if (!form.work_plan?.trim()) return; onSave(form); }}
            className="h-9 px-4 text-[13px] font-medium bg-[#185FA5] text-white rounded-lg
              hover:bg-[#0C447C] transition-colors flex items-center gap-1.5">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
            {isEdit ? "Update task" : "Add task"}
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Main WorkDiaryForm ───────────────────────────────────────────────────────
const WorkDiaryForm = ({
  mode           = "view",
  onSave,
  onCancel,
  onDelete,
  onEditCancel,
  saving,
  onModify,
  onNewEntry,
  currentRecord,
  totalRecords,
  rights,
  activeTab      = "entry",
  onTabChange    = () => {},
  formData,
  setFormData,
  employees      = [],
  onCopyYesterday = null,
}) => {
  const [tasks,       setTasks]      = useState(() => {
    const lines = formData?.task_lines;
    return Array.isArray(lines) && lines.length > 0
      ? lines.map(t => ({ ...newTask(), ...t, _key: t._key || crypto.randomUUID() }))
      : [newTask()];
  });
  const [viewMode,    setViewMode]   = useState("grid");   // "grid" | "list"
  const [filter,      setFilter]     = useState("all");
  const [search,      setSearch]     = useState("");
  const [detailKey,   setDetailKey]  = useState(null);
  const [modalTask,   setModalTask]  = useState(null);     // null = closed, {} = add, task = edit
  const [errors,      setErrors]     = useState({});

  const isViewMode = mode === "view";
  const isAddMode  = mode === "add";
  const isEditMode = mode === "edit";

  // sync task_lines into formData whenever tasks change
  const syncTasks = useCallback((updated) => {
    setTasks(updated);
    setFormData(prev => ({ ...prev, task_lines: updated.map(({ _key, ...rest }) => rest) }));
  }, [setFormData]);

  // ── Stats ──────────────────────────────────────────────────
  const today = new Date().toISOString().split("T")[0];
  const totalTasks    = tasks.length;
  const inProgress    = tasks.filter(t => t.status === "In Progress").length;
  const completed     = tasks.filter(t => t.status === "Completed").length;
  const overdue       = tasks.filter(t => t.due_date && t.due_date < today && t.status !== "Completed" && t.status !== "Cancelled").length;
  const totalExpHrs   = tasks.reduce((s, t) => s + (parseFloat(t.expected_time) || 0), 0);
  const totalActHrs   = tasks.reduce((s, t) => s + (parseFloat(t.actual_time)   || 0), 0);

  // ── Filtered tasks ─────────────────────────────────────────
  const filtered = useMemo(() => {
    let list = [...tasks];
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(t =>
        t.work_plan?.toLowerCase().includes(q) ||
        t.target?.toLowerCase().includes(q) ||
        t.category?.toLowerCase().includes(q)
      );
    }
    switch (filter) {
      case "inprogress": return list.filter(t => t.status === "In Progress");
      case "completed":  return list.filter(t => t.status === "Completed");
      case "pending":    return list.filter(t => t.status === "Pending");
      case "overdue":    return list.filter(t => t.due_date && t.due_date < today && t.status !== "Completed" && t.status !== "Cancelled");
      case "high":       return list.filter(t => t.priority === "High");
      default:           return list;
    }
  }, [tasks, filter, search, today]);

  const detailTask = tasks.find(t => t._key === detailKey) || null;

  // ── Task CRUD ──────────────────────────────────────────────
  const handleToggleDone = (key) => {
    syncTasks(tasks.map(t => t._key === key
      ? { ...t, status: t.status === "Completed" ? "Pending" : "Completed" }
      : t
    ));
  };

  const handleDeleteTask = (key) => {
    if (tasks.length === 1) return;
    syncTasks(tasks.filter(t => t._key !== key));
    if (detailKey === key) setDetailKey(null);
  };

  const handleSaveModal = (form) => {
    const exists = tasks.find(t => t._key === form._key);
    if (exists) {
      syncTasks(tasks.map(t => t._key === form._key ? form : t));
      if (detailKey === form._key) setDetailKey(form._key);
    } else {
      syncTasks([...tasks, { ...form, _key: crypto.randomUUID() }]);
    }
    setModalTask(null);
  };

  // ── Diary save ─────────────────────────────────────────────
  const handleValidateAndSave = useCallback((submitForApproval = false) => {
    if (isViewMode) return;
    const errs = {};
    if (!formData.employee_id) errs.employee_id = "Required";
    if (!formData.diary_date)  errs.diary_date  = "Required";
    if (tasks.every(t => !t.work_plan?.trim())) errs._tasks = "Add at least one task";
    if (Object.keys(errs).length) { setErrors(errs); return; }
    onSave && onSave({
      ...formData,
      diary_status: submitForApproval ? "Submitted" : (formData.diary_status || "Draft"),
      task_lines: tasks.map(({ _key, ...rest }) => rest),
    });
  }, [formData, tasks, isViewMode, onSave]);

  const FILTER_PILLS = [
    { key:"all",        label:"All"         },
    { key:"pending",    label:"Pending"     },
    { key:"inprogress", label:"In Progress" },
    { key:"completed",  label:"Completed"   },
    { key:"high",       label:"🔴 High"     },
    { key:"overdue",    label:"⚠ Overdue"   },
  ];

  return (
    <div className="w-full h-[calc(100vh-120px)] flex flex-col" style={{ fontFamily: FONT }}>

      {/* ── ERP Header ── */}
      <ERPHeader
        title="WORK DIARY"
        isAddMode={isAddMode}
        isEditMode={isEditMode}
        isViewMode={isViewMode}
        activeTab={activeTab}
        onTabChange={onTabChange}
        rightContent={`${currentRecord || 1} / ${totalRecords || 1}`}
      />

      {/* ── Diary meta bar ── */}
      <div className="bg-white border-b border-slate-200 px-4 py-2 flex flex-wrap items-center gap-3 shrink-0">
        {/* Employee */}
        <div className="flex items-center gap-2">
          <Avatar name={formData.employee_name || "?"} size="w-7 h-7 text-[10px]" />
          <span className="text-[13px] font-semibold text-slate-700">{formData.employee_name || "—"}</span>
          {formData.department && <span className="text-[11px] text-slate-400">· {formData.department}</span>}
        </div>
        <span className="text-slate-200">|</span>
        {/* Date */}
        {isViewMode ? (
          <span className="text-[12px] text-slate-600 font-medium">{formData.diary_date || "—"}</span>
        ) : (
          <input
            type="date"
            value={formData.diary_date || ""}
            onChange={e => { setFormData(p => ({ ...p, diary_date: e.target.value })); if (errors.diary_date) setErrors(p => ({ ...p, diary_date: undefined })); }}
            className={`h-8 px-2 text-[12px] border rounded-lg outline-none focus:border-[#378ADD]
              ${errors.diary_date ? "border-red-400 bg-red-50" : "border-slate-200 bg-white"}`}
          />
        )}
        <span className="text-slate-200">|</span>
        {/* Diary status */}
        <Pill label={formData.diary_status || "Draft"} cls={STATUS_CFG[formData.diary_status] || STATUS_CFG.Draft} />
        {/* Period */}
        <span className="text-[11px] text-slate-400">{formData.period_type || "Daily"}</span>

        {/* Right actions */}
        <div className="ml-auto flex items-center gap-2">
          {!isViewMode && onCopyYesterday && (
            <button onClick={onCopyYesterday}
              className="flex items-center gap-1 h-8 px-3 text-[12px] text-slate-500 border border-slate-200
                rounded-lg hover:bg-slate-50 transition-colors">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
              </svg>
              Copy yesterday
            </button>
          )}
          {!isViewMode && (
            <button onClick={() => setModalTask(newTask())}
              className="flex items-center gap-1.5 h-8 px-3 text-[12px] font-medium text-white
                bg-[#185FA5] hover:bg-[#0C447C] rounded-lg transition-colors">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
              </svg>
              Add task
            </button>
          )}
          {!isViewMode && (
            <button onClick={() => handleValidateAndSave(true)}
              className="flex items-center gap-1.5 h-8 px-3 text-[12px] font-medium text-white
                bg-[#3C3489] hover:bg-[#2a2462] rounded-lg transition-colors">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
              </svg>
              Submit
            </button>
          )}
        </div>
      </div>

      {/* ── Body: content + detail panel ── */}
      <div className="flex-1 flex overflow-hidden bg-slate-50">

        {/* ── Main content area ── */}
        <div className="flex-1 flex flex-col overflow-hidden">

          {/* Stats row */}
          <div className="px-4 pt-4 pb-2 grid grid-cols-2 lg:grid-cols-5 gap-3 shrink-0">
            <StatCard icon={<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#7c6fff" strokeWidth="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg>}
              value={totalTasks} label="Total Tasks" sub="All diary entries"
              accent="bg-[#EEEDFE] text-[#3C3489]" />
            <StatCard icon={<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#185FA5" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>}
              value={inProgress} label="In Progress" sub={totalTasks ? `${Math.round(inProgress/totalTasks*100)}% of total` : "0%"}
              accent="bg-[#E6F1FB] text-[#185FA5]" />
            <StatCard icon={<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#639922" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>}
              value={completed} label="Completed" sub={totalTasks ? `${Math.round(completed/totalTasks*100)}% done` : "0%"}
              accent="bg-[#EAF3DE] text-[#27500A]" />
            <StatCard icon={<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#E24B4A" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>}
              value={overdue} label="Overdue" sub={overdue > 0 ? "Needs attention" : "All on track 🎉"}
              accent="bg-[#FCEBEB] text-[#791F1F]" />
            <StatCard icon={<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#854F0B" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>}
              value={`${fmtHrs(totalActHrs)}h`} label="Hours logged"
              sub={`of ${fmtHrs(totalExpHrs)}h planned`}
              accent="bg-[#FAEEDA] text-[#633806]" />
          </div>

          {/* Section header + filters */}
          <div className="px-4 pt-2 shrink-0">
            <div className="flex items-center gap-3 mb-3">
              <span className="text-[14px] font-semibold text-slate-700">Tasks</span>
              <span className="text-[11px] bg-slate-200 text-slate-500 font-semibold px-2 py-0.5 rounded-full">
                {filtered.length}
              </span>
              {/* Search */}
              <div className="relative ml-2 flex-1 max-w-[280px]">
                <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                </svg>
                <input value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Search tasks..."
                  className="w-full h-8 pl-7 pr-3 text-[12px] border border-slate-200 rounded-lg outline-none
                    focus:border-[#378ADD] bg-white" />
              </div>
              {/* View toggle */}
              <div className="ml-auto flex bg-white border border-slate-200 rounded-lg p-0.5 gap-0.5">
                {[["grid","M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z"],
                  ["list","M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"]].map(([v, d]) => (
                  <button key={v} onClick={() => setViewMode(v)}
                    className={`p-1.5 rounded-md transition-colors ${viewMode === v ? "bg-slate-100 text-slate-700" : "text-slate-400 hover:text-slate-600"}`}>
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d={d}/>
                    </svg>
                  </button>
                ))}
              </div>
            </div>

            {/* Filter pills */}
            <div className="flex gap-1.5 flex-wrap mb-3">
              {FILTER_PILLS.map(fp => (
                <button key={fp.key} onClick={() => setFilter(fp.key)}
                  className={`px-3 py-1 rounded-full text-[11px] font-medium border transition-all
                    ${filter === fp.key
                      ? "bg-[#E6F1FB] border-[#85B7EB] text-[#185FA5]"
                      : "bg-white border-slate-200 text-slate-500 hover:border-slate-300 hover:text-slate-700"}`}>
                  {fp.label}
                </button>
              ))}
            </div>
          </div>

          {/* Task list / grid */}
          <div className="flex-1 overflow-y-auto px-4 pb-4">
            {filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-slate-300 gap-3">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
                  <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/>
                  <rect x="9" y="3" width="6" height="4" rx="1"/><path d="M9 12h6M9 16h4"/>
                </svg>
                <div className="text-center">
                  <div className="text-[13px] text-slate-400 font-medium">No tasks found</div>
                  {!isViewMode && (
                    <button onClick={() => setModalTask(newTask())}
                      className="mt-2 text-[12px] text-[#185FA5] hover:underline">+ Add your first task</button>
                  )}
                </div>
              </div>
            ) : viewMode === "grid" ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
                {filtered.map(t => (
                  <TaskCard key={t._key} task={t}
                    onOpen={setDetailKey}
                    onToggleDone={handleToggleDone}
                    onDelete={handleDeleteTask} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {filtered.map(t => (
                  <TaskRow key={t._key} task={t}
                    onOpen={setDetailKey}
                    onToggleDone={handleToggleDone}
                    onDelete={handleDeleteTask} />
                ))}
              </div>
            )}
          </div>

          {/* Notes bar */}
          {!isViewMode && (
            <div className="px-4 pb-2 shrink-0">
              <textarea
                value={formData.notes || ""}
                onChange={e => setFormData(p => ({ ...p, notes: e.target.value }))}
                placeholder="Diary notes / blockers..."
                rows={2}
                className="w-full px-3 py-2 text-[12px] border border-slate-200 rounded-xl outline-none
                  focus:border-[#378ADD] bg-white resize-none leading-relaxed"
              />
            </div>
          )}
          {isViewMode && formData.notes && (
            <div className="px-4 pb-2 shrink-0">
              <div className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-[12px] text-slate-600 leading-relaxed">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">Notes</span>
                {formData.notes}
              </div>
            </div>
          )}
        </div>

        {/* ── Detail panel ── */}
        {detailTask && (
          <DetailPanel
            task={detailTask}
            onClose={() => setDetailKey(null)}
            onEdit={() => { setModalTask(detailTask); }}
            onDelete={(key) => { handleDeleteTask(key); setDetailKey(null); }}
            onToggleDone={handleToggleDone}
            isViewMode={isViewMode}
          />
        )}
      </div>

      {/* ── ERP Footer ── */}
      <ERPFooter
        isAddMode={isAddMode}
        isEditMode={isEditMode}
        isViewMode={isViewMode}
        saving={saving}
        handleSubmit={() => handleValidateAndSave(false)}
        onModify={onModify}
        onDelete={() => onDelete && onDelete(formData)}
        onCancel={onCancel}
        onEditCancel={onEditCancel}
        onNewEntry={onNewEntry}
        rights={rights}
      />

      {/* ── Add/Edit Modal ── */}
      {modalTask !== null && (
        <TaskModal
          task={modalTask}
          onClose={() => setModalTask(null)}
          onSave={handleSaveModal}
        />
      )}

      {/* ── Validation error toast ── */}
      {errors._tasks && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-[#FCEBEB] border border-[#F7C1C1]
          text-[#791F1F] text-[12px] px-4 py-2 rounded-lg shadow-lg">
          {errors._tasks}
        </div>
      )}
    </div>
  );
};

export default WorkDiaryForm;
